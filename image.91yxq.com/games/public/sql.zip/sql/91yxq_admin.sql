/*
Navicat MySQL Data Transfer

Source Server         : 58.215.142.186
Source Server Version : 50533
Source Host           : 58.215.142.186:3306
Source Database       : 91yxq_admin

Target Server Type    : MYSQL
Target Server Version : 50533
File Encoding         : 65001

Date: 2017-12-28 13:39:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for 91yxq_admin_group
-- ----------------------------
DROP TABLE IF EXISTS `91yxq_admin_group`;
CREATE TABLE `91yxq_admin_group` (
  `gId` int(10) NOT NULL AUTO_INCREMENT,
  `gName` varchar(100) NOT NULL COMMENT '组名称',
  `cUser` int(10) NOT NULL DEFAULT '0' COMMENT '创建者id',
  `cTime` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updUser` int(10) NOT NULL DEFAULT '0' COMMENT '最后修改者id',
  `updTime` int(10) NOT NULL DEFAULT '0' COMMENT '最后修改时间',
  `gState` tinyint(1) NOT NULL DEFAULT '1' COMMENT '组当前状态',
  `gGrants` text NOT NULL COMMENT '组权限，序列化数组',
  `px` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  KEY `gId` (`gId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户分组表';

-- ----------------------------
-- Records of 91yxq_admin_group
-- ----------------------------
INSERT INTO `91yxq_admin_group` VALUES ('1', '超管', '0', '1444461853', '0', '1444461853', '1', 'all', '0');
INSERT INTO `91yxq_admin_group` VALUES ('2', 'test', '123', '1487067294', '123', '1509521509', '1', 'a:75:{i:0;s:4:\"1100\";i:3;d:1000;i:4;s:4:\"1102\";i:8;s:4:\"1103\";i:12;s:4:\"1104\";i:16;s:4:\"1105\";i:20;s:4:\"1106\";i:24;s:4:\"1107\";i:28;s:4:\"1108\";i:32;s:4:\"1109\";i:36;s:4:\"1110\";i:40;s:4:\"1111\";i:44;s:4:\"1112\";i:48;s:4:\"1113\";i:52;s:4:\"1114\";i:56;s:4:\"1200\";i:60;s:4:\"1201\";i:64;s:4:\"1202\";i:68;s:4:\"1203\";i:72;s:4:\"1204\";i:76;s:4:\"1205\";i:80;s:4:\"1206\";i:84;s:4:\"1207\";i:88;s:4:\"1300\";i:92;s:4:\"1301\";i:96;s:4:\"1302\";i:100;s:4:\"1303\";i:104;s:4:\"1304\";i:108;s:4:\"1305\";i:112;s:4:\"1306\";i:116;s:4:\"1307\";i:120;s:4:\"1308\";i:124;s:4:\"1309\";i:128;s:4:\"1310\";i:132;s:4:\"1311\";i:136;s:4:\"1312\";i:140;s:4:\"1400\";i:144;s:4:\"1401\";i:148;s:4:\"1402\";i:152;s:4:\"2200\";i:155;d:2000;i:156;s:4:\"2201\";i:160;s:4:\"2202\";i:164;s:4:\"2203\";i:168;s:4:\"2204\";i:172;s:4:\"2205\";i:176;s:4:\"3100\";i:179;d:3000;i:180;s:4:\"3101\";i:184;s:4:\"3110\";i:188;s:4:\"3102\";i:192;s:4:\"3103\";i:196;s:4:\"3104\";i:200;s:4:\"3105\";i:204;s:4:\"3106\";i:208;s:4:\"3107\";i:212;s:4:\"3108\";i:216;s:4:\"3109\";i:220;s:4:\"3201\";i:221;d:3200;i:224;s:4:\"3202\";i:228;s:4:\"3203\";i:232;s:4:\"3204\";i:236;s:4:\"4101\";i:237;d:4100;i:239;d:4000;i:240;s:4:\"4102\";i:244;s:4:\"5101\";i:245;d:5100;i:247;d:5000;i:248;s:4:\"5102\";i:252;s:4:\"5201\";i:253;d:5200;i:256;s:4:\"5202\";i:260;s:4:\"5205\";}', '100');

-- ----------------------------
-- Table structure for 91yxq_admin_users
-- ----------------------------
DROP TABLE IF EXISTS `91yxq_admin_users`;
CREATE TABLE `91yxq_admin_users` (
  `uid` int(10) NOT NULL AUTO_INCREMENT COMMENT '管理人员ID',
  `uName` varchar(200) NOT NULL COMMENT '管理人员名称',
  `uAccount` varchar(255) NOT NULL COMMENT '登录账号',
  `uPass` varchar(32) NOT NULL COMMENT '登陆密码',
  `uAttend` varchar(6) NOT NULL COMMENT '附加验证码',
  `uGroupId` int(10) NOT NULL DEFAULT '0' COMMENT '用户分组id',
  `uGuildList` int(10) NOT NULL DEFAULT '0' COMMENT '管理公会列表，序列化存储',
  `uPhone` varchar(20) NOT NULL COMMENT '玩家联系方式',
  `uMail` varchar(255) NOT NULL COMMENT '用户mail',
  `uCreateTime` int(10) NOT NULL COMMENT '账号创建时间',
  `uLastLoginTime` int(10) NOT NULL COMMENT '上次登录时间',
  `uLastLoginIp` varchar(20) NOT NULL COMMENT '上次登录ip',
  `uLoginAddress` varchar(50) DEFAULT NULL COMMENT '登录地址',
  `uLoginCount` int(10) NOT NULL DEFAULT '0' COMMENT '用户登录次数',
  `uLoginState` tinyint(1) NOT NULL DEFAULT '1' COMMENT '账号状态：1代表账号有效，0代表无效',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=128 DEFAULT CHARSET=utf8 COMMENT='管理人员列表';

-- ----------------------------
-- Records of 91yxq_admin_users
-- ----------------------------
INSERT INTO `91yxq_admin_users` VALUES ('123', '管理员', 'admin', '72ad5a761545c4a674dfc566b85c4f74', 'Q/.;O8', '1', '0', '', '', '0', '1514429373', '180.110.209.101', '江苏南京', '3368', '1');
INSERT INTO `91yxq_admin_users` VALUES ('126', 'sjz', 'sjz', '08718ec04b1ecb3706ab07a26b3e0f89', '_:7]^U', '1', '0', '', '', '0', '1486954139', '58.240.26.114', '江苏南京', '2', '1');
INSERT INTO `91yxq_admin_users` VALUES ('127', 'test', 'test', '4b7778aced117e8599d60ab7763e31ad', 'xMitD=', '2', '0', '', '', '0', '1509521520', '58.240.26.114', '江苏南京', '4', '1');

-- ----------------------------
-- Table structure for adlist
-- ----------------------------
DROP TABLE IF EXISTS `adlist`;
CREATE TABLE `adlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  `adid` varchar(20) NOT NULL DEFAULT '',
  `memo` varchar(60) NOT NULL DEFAULT '',
  `addtime` datetime NOT NULL,
  `hf` tinyint(1) NOT NULL DEFAULT '0',
  `state` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '0未审核，1已审核，2停用，3测试，4删除',
  `author` varchar(20) NOT NULL,
  `platformid` int(11) NOT NULL DEFAULT '0',
  `voice` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0无声音，1有声音',
  `copyfrom` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 抄袭，1 原创',
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0 冲注册，1 贴题',
  `new` tinyint(1) NOT NULL DEFAULT '1',
  `green` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有绿色版，0 没有，1 有',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adlist
-- ----------------------------

-- ----------------------------
-- Table structure for agent
-- ----------------------------
DROP TABLE IF EXISTS `agent`;
CREATE TABLE `agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) NOT NULL COMMENT '管理账号',
  `user_pwd` varchar(50) NOT NULL DEFAULT '123456' COMMENT '管理密码',
  `agentname` varchar(30) NOT NULL COMMENT '公会名称',
  `agenttype` tinyint(1) NOT NULL DEFAULT '1' COMMENT '渠道类型，1为公会，默认为其他媒体',
  `person` varchar(30) NOT NULL DEFAULT '' COMMENT '联系姓名',
  `url` varchar(50) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '用户邮箱',
  `tel` varchar(25) NOT NULL DEFAULT '' COMMENT '联系电话',
  `ip` varchar(50) NOT NULL DEFAULT '' COMMENT '注册ip',
  `qq` varchar(50) DEFAULT '' COMMENT 'qq',
  `yy` varchar(20) DEFAULT NULL COMMENT 'YY公会号',
  `bank` varchar(100) DEFAULT '' COMMENT '开户银行',
  `bank_son` varchar(40) DEFAULT NULL COMMENT '开户支行',
  `province` varchar(50) NOT NULL COMMENT '省份',
  `city` varchar(50) NOT NULL COMMENT '城市',
  `account_name` varchar(50) DEFAULT NULL COMMENT '开户人',
  `account` varchar(30) NOT NULL DEFAULT '' COMMENT '银行账户',
  `mobel` varchar(20) DEFAULT NULL COMMENT '联系电话',
  `idcard` varchar(18) DEFAULT NULL COMMENT '身份证号',
  `lastip` varchar(50) NOT NULL DEFAULT '' COMMENT '最后登录ip',
  `loginaddress` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `lastdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后登录时间',
  `logincount` int(10) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `adduid` int(10) NOT NULL COMMENT '添加者ID',
  `add_date` datetime NOT NULL COMMENT '注册时间/添加时间',
  `revise_uid` int(10) NOT NULL DEFAULT '0' COMMENT '最后修改者',
  `revise_date` datetime DEFAULT NULL COMMENT '最后修改时间',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态(0:未审核,1:审核)',
  `utime` int(10) NOT NULL DEFAULT '0' COMMENT '银行信息最后修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10033 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of agent
-- ----------------------------
INSERT INTO `agent` VALUES ('100', '91yxq', '91yxq', '平台', '1', '', '', '', '', '', '', null, '', null, '广东', '广州', null, '', null, null, '183.54.201.204', '广东广州', '2016-03-03 10:40:55', '17', '123', '2015-11-06 16:06:54', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10006', 'admin1', '85619286', 'gonghui1', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-08-02 14:56:12', '77', '123', '2017-03-21 09:34:58', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10007', 'admin2', '85619286', 'gonghui2', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-06-30 14:14:20', '60', '123', '2017-03-21 09:35:16', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10008', 'admin3', '85619286', 'gonghui3', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-06-30 14:14:39', '51', '123', '2017-03-21 09:35:33', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10009', 'admin4', '85619286', 'gonghui4', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-06-30 14:14:58', '22', '123', '2017-03-21 09:35:48', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10010', 'admin5', 'wm1111', 'pceggs', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-08-16 09:55:37', '50', '123', '2017-03-21 09:36:04', '123', '2017-09-19 10:34:46', '1', '0');
INSERT INTO `agent` VALUES ('10011', 'admin6', '5822089', 'gonghui6', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '180.102.200.23', '江苏南京', '2017-09-26 15:55:36', '69', '123', '2017-03-21 09:36:20', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10013', 'admin7', '5822089', 'gonghui7', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '58.240.26.114', '江苏南京', '2017-06-30 14:11:24', '1', '123', '2017-06-30 11:13:04', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10014', 'admin8', '111111', 'bengbeng', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-07-14 14:14:16', '123', '2017-09-19 10:33:59', '1', '0');
INSERT INTO `agent` VALUES ('10015', 'admin9', '111111', 'kuailezhuan', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-07-25 16:11:05', '123', '2017-09-12 14:56:48', '1', '0');
INSERT INTO `agent` VALUES ('10016', 'admin10', '111111', 'juxiangyou', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-08-04 16:06:35', '123', '2017-09-12 14:56:36', '1', '0');
INSERT INTO `agent` VALUES ('10017', 'admin11', '111111', 'quba', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-08-04 16:06:51', '123', '2017-09-12 14:55:30', '1', '0');
INSERT INTO `agent` VALUES ('10020', 'mocuz', '111111', 'mocuz', '1', '', 'http://demo.mocuz.com/', '', '', '', '', null, '', null, '', '0', null, '', null, null, '49.77.234.240', '江苏南京', '2017-10-13 16:41:43', '5', '0', '2017-08-07 15:31:09', '123', '2017-08-14 09:23:15', '1', '0');
INSERT INTO `agent` VALUES ('10021', 'stationmaster', '111111', 'stationmaster', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '180.110.208.25', '江苏南京', '2017-11-03 15:03:48', '1', '123', '2017-10-31 13:37:45', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10025', 'youyiwang', '111111', 'youyiwang', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-08-24 10:46:33', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10026', 'shitoucun', '111111', 'shitoucun', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-08-24 10:46:51', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10027', 'tiantianzuan', '111111', 'tiantianzuan', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-08-25 10:54:33', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10028', 'ledouwan', '111111', 'ledouwan', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-09-13 16:14:11', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10029', 'jiquwang', '111111', 'jiquwang', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-09-13 16:15:38', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10030', 'jujuwan', '111111', 'jujuwan', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-10-25 11:11:27', '0', null, '1', '0');
INSERT INTO `agent` VALUES ('10032', 'yiruite', '111111', 'yiruite', '1', '', '', '', '', '', '', null, '', null, '', '0', null, '', null, null, '', null, '0000-00-00 00:00:00', '0', '123', '2017-11-09 10:01:11', '0', null, '1', '0');

-- ----------------------------
-- Table structure for agent_colonel
-- ----------------------------
DROP TABLE IF EXISTS `agent_colonel`;
CREATE TABLE `agent_colonel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agenttype` tinyint(4) NOT NULL DEFAULT '0' COMMENT '公会团长类型，1为军团长',
  `agent_name` varchar(30) NOT NULL COMMENT '团长名称',
  `yy` varchar(20) DEFAULT NULL COMMENT 'yy号',
  `qq` varchar(50) DEFAULT NULL COMMENT 'QQ号',
  `bank` varchar(30) NOT NULL COMMENT '银行账户',
  `acount_name` varchar(50) NOT NULL COMMENT '银行开户人',
  `mobel` varchar(20) DEFAULT NULL COMMENT '电话',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公会团长表';

-- ----------------------------
-- Records of agent_colonel
-- ----------------------------

-- ----------------------------
-- Table structure for agent_del_spreadurl
-- ----------------------------
DROP TABLE IF EXISTS `agent_del_spreadurl`;
CREATE TABLE `agent_del_spreadurl` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL,
  `placeid` int(10) NOT NULL,
  `game_id` int(10) NOT NULL,
  `server_id` int(10) NOT NULL,
  `addTime` int(10) NOT NULL,
  `addUid` int(10) NOT NULL,
  `addUser` varchar(30) NOT NULL COMMENT '操作人',
  `opUserList` text NOT NULL,
  `ifback` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1表示已还原，0表示已删除链接',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COMMENT='删除公会推广链接记录表';

-- ----------------------------
-- Records of agent_del_spreadurl
-- ----------------------------

-- ----------------------------
-- Table structure for agent_delete
-- ----------------------------
DROP TABLE IF EXISTS `agent_delete`;
CREATE TABLE `agent_delete` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL COMMENT '公会id',
  `agent_name` varchar(50) NOT NULL COMMENT '公会名',
  `del_userid` int(10) NOT NULL COMMENT '操作人',
  `del_time` datetime NOT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='公会删除日记表';

-- ----------------------------
-- Records of agent_delete
-- ----------------------------
INSERT INTO `agent_delete` VALUES ('1', '10024', '168_10024', '123', '2017-08-14 10:13:31');
INSERT INTO `agent_delete` VALUES ('2', '10023', 'gonghui100', '123', '2017-08-14 10:13:35');
INSERT INTO `agent_delete` VALUES ('3', '10022', '_10022', '123', '2017-08-14 10:13:39');
INSERT INTO `agent_delete` VALUES ('4', '10021', 'xiangmu3_10021', '123', '2017-08-14 10:13:43');
INSERT INTO `agent_delete` VALUES ('5', '10004', 'www.jd.com', '123', '2017-09-19 10:31:20');
INSERT INTO `agent_delete` VALUES ('6', '10003', '哈哈', '123', '2017-09-19 10:31:25');
INSERT INTO `agent_delete` VALUES ('7', '10005', 'www.jdjd.com', '123', '2017-09-19 10:31:31');
INSERT INTO `agent_delete` VALUES ('8', '10001', 'wulei', '123', '2017-09-19 10:31:37');
INSERT INTO `agent_delete` VALUES ('9', '10002', 'wast', '123', '2017-09-19 10:31:49');
INSERT INTO `agent_delete` VALUES ('10', '10012', 'http://192.168.20.6/', '123', '2017-09-19 10:31:59');

-- ----------------------------
-- Table structure for agent_into
-- ----------------------------
DROP TABLE IF EXISTS `agent_into`;
CREATE TABLE `agent_into` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_name` varchar(30) NOT NULL COMMENT '团长名称',
  `yy` varchar(20) DEFAULT NULL COMMENT 'yy号',
  `qq` varchar(50) DEFAULT NULL COMMENT 'QQ号',
  `bank` varchar(30) NOT NULL COMMENT '银行账户',
  `acount_name` varchar(50) NOT NULL COMMENT '银行开户人',
  `mobel` varchar(20) DEFAULT NULL COMMENT '电话',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='公会录入';

-- ----------------------------
-- Records of agent_into
-- ----------------------------

-- ----------------------------
-- Table structure for agent_login_log
-- ----------------------------
DROP TABLE IF EXISTS `agent_login_log`;
CREATE TABLE `agent_login_log` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL,
  `longin_time` datetime NOT NULL,
  `longin_ip` varchar(20) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=129485 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of agent_login_log
-- ----------------------------
INSERT INTO `agent_login_log` VALUES ('129121', '10000', '2015-11-21 19:50:44', '58.62.163.251');
INSERT INTO `agent_login_log` VALUES ('129122', '10000', '2015-11-25 09:57:41', '113.109.103.186');
INSERT INTO `agent_login_log` VALUES ('129123', '10000', '2015-11-30 09:53:52', '58.61.233.85');
INSERT INTO `agent_login_log` VALUES ('129124', '10000', '2015-11-30 10:20:46', '58.61.233.85');
INSERT INTO `agent_login_log` VALUES ('129125', '10000', '2015-12-13 21:27:32', '61.140.53.175');
INSERT INTO `agent_login_log` VALUES ('129126', '10000', '2015-12-17 20:18:35', '58.62.162.253');
INSERT INTO `agent_login_log` VALUES ('129127', '10000', '2015-12-17 20:20:05', '58.62.162.253');
INSERT INTO `agent_login_log` VALUES ('129128', '10000', '2016-01-02 11:02:26', '58.63.89.148');
INSERT INTO `agent_login_log` VALUES ('129129', '10000', '2016-01-23 15:24:14', '113.68.44.173');
INSERT INTO `agent_login_log` VALUES ('129130', '10000', '2016-01-24 10:12:05', '113.68.44.173');
INSERT INTO `agent_login_log` VALUES ('129131', '10000', '2016-02-26 14:48:57', '58.63.89.81');
INSERT INTO `agent_login_log` VALUES ('129132', '10000', '2016-02-26 14:50:13', '183.54.200.237');
INSERT INTO `agent_login_log` VALUES ('129133', '10000', '2016-02-29 14:18:37', '183.54.202.94');
INSERT INTO `agent_login_log` VALUES ('129134', '10000', '2016-03-01 13:53:30', '183.54.202.94');
INSERT INTO `agent_login_log` VALUES ('129135', '10000', '2016-03-02 17:56:01', '183.54.201.204');
INSERT INTO `agent_login_log` VALUES ('129136', '10000', '2016-03-02 18:08:16', '183.54.201.204');
INSERT INTO `agent_login_log` VALUES ('129137', '10000', '2016-03-03 10:40:55', '183.54.201.204');
INSERT INTO `agent_login_log` VALUES ('129138', '10001', '2016-12-15 15:46:10', '101.81.224.51');
INSERT INTO `agent_login_log` VALUES ('129139', '10001', '2016-12-30 20:06:20', '58.38.163.16');
INSERT INTO `agent_login_log` VALUES ('129140', '10001', '2017-01-02 20:17:32', '58.38.201.30');
INSERT INTO `agent_login_log` VALUES ('129141', '10001', '2017-01-07 17:34:50', '180.157.215.192');
INSERT INTO `agent_login_log` VALUES ('129142', '10001', '2017-02-07 18:20:52', '114.222.186.68');
INSERT INTO `agent_login_log` VALUES ('129143', '10002', '2017-02-10 12:42:55', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129144', '10003', '2017-02-10 16:57:09', '49.65.249.195');
INSERT INTO `agent_login_log` VALUES ('129145', '10003', '2017-02-10 16:58:45', '49.65.249.195');
INSERT INTO `agent_login_log` VALUES ('129146', '10001', '2017-02-16 19:15:49', '116.21.180.83');
INSERT INTO `agent_login_log` VALUES ('129147', '10002', '2017-02-23 11:20:41', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129148', '10006', '2017-03-21 10:14:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129149', '10006', '2017-03-21 10:41:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129150', '10006', '2017-03-21 10:49:23', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129151', '10007', '2017-03-21 11:18:53', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129152', '10008', '2017-03-21 11:20:39', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129153', '10006', '2017-03-21 16:09:02', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129154', '10009', '2017-03-23 13:50:21', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129155', '10006', '2017-03-23 13:50:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129156', '10006', '2017-03-23 14:34:47', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129157', '10006', '2017-03-23 14:35:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129158', '10006', '2017-03-23 14:40:54', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129159', '10007', '2017-03-23 14:42:14', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129160', '10007', '2017-03-23 14:45:56', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129161', '10006', '2017-03-23 14:55:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129162', '10008', '2017-03-23 14:59:49', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129163', '10007', '2017-03-23 15:07:45', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129164', '10008', '2017-03-23 15:09:06', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129165', '10007', '2017-03-23 15:25:23', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129166', '10008', '2017-03-23 15:30:05', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129167', '10006', '2017-03-23 15:32:19', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129168', '10008', '2017-03-23 16:01:50', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129169', '10008', '2017-03-23 16:17:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129170', '10007', '2017-03-23 16:18:49', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129171', '10008', '2017-03-23 16:19:15', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129172', '10007', '2017-03-23 16:19:32', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129173', '10006', '2017-03-23 16:20:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129174', '10006', '2017-03-23 16:20:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129175', '10006', '2017-03-23 17:00:24', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129176', '10008', '2017-03-23 17:06:40', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129177', '10007', '2017-03-23 17:07:25', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129178', '10006', '2017-03-23 17:31:35', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129179', '10008', '2017-03-23 17:56:50', '49.77.238.190');
INSERT INTO `agent_login_log` VALUES ('129180', '10008', '2017-03-23 18:38:37', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129181', '10006', '2017-03-23 20:04:42', '222.95.223.98');
INSERT INTO `agent_login_log` VALUES ('129182', '10007', '2017-03-23 20:07:05', '222.95.223.98');
INSERT INTO `agent_login_log` VALUES ('129183', '10008', '2017-03-23 20:07:40', '222.95.223.98');
INSERT INTO `agent_login_log` VALUES ('129184', '10006', '2017-03-23 22:58:01', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129185', '10007', '2017-03-23 23:01:52', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129186', '10008', '2017-03-23 23:03:16', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129187', '10007', '2017-03-23 23:09:17', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129188', '10006', '2017-03-23 23:09:49', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129189', '10008', '2017-03-23 23:11:14', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129190', '10006', '2017-03-23 23:12:30', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129191', '10007', '2017-03-23 23:17:09', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129192', '10008', '2017-03-23 23:18:19', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129193', '10006', '2017-03-24 09:48:11', '49.77.226.96');
INSERT INTO `agent_login_log` VALUES ('129194', '10007', '2017-03-24 09:54:31', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129195', '10008', '2017-03-24 09:55:18', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129196', '10006', '2017-03-24 12:54:43', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129197', '10007', '2017-03-24 12:56:53', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129198', '10008', '2017-03-24 12:58:25', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129199', '10009', '2017-03-24 12:59:02', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129200', '10008', '2017-03-24 12:59:16', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129201', '10007', '2017-03-24 16:10:21', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129202', '10010', '2017-03-24 16:10:45', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129203', '10007', '2017-03-24 16:17:11', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129204', '10006', '2017-03-24 16:17:25', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129205', '10007', '2017-03-24 16:24:48', '49.77.226.96');
INSERT INTO `agent_login_log` VALUES ('129206', '10008', '2017-03-24 16:25:20', '49.77.226.96');
INSERT INTO `agent_login_log` VALUES ('129207', '10006', '2017-03-24 16:29:05', '49.77.226.96');
INSERT INTO `agent_login_log` VALUES ('129208', '10008', '2017-03-24 17:21:26', '49.77.226.96');
INSERT INTO `agent_login_log` VALUES ('129209', '10006', '2017-03-24 17:26:59', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129210', '10008', '2017-03-24 17:39:06', '117.89.51.45');
INSERT INTO `agent_login_log` VALUES ('129211', '10006', '2017-03-24 22:25:35', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129212', '10007', '2017-03-24 22:29:51', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129213', '10008', '2017-03-24 22:30:49', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129214', '10006', '2017-03-25 00:05:56', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129215', '10007', '2017-03-25 00:06:24', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129216', '10008', '2017-03-25 00:06:40', '121.237.62.62');
INSERT INTO `agent_login_log` VALUES ('129217', '10007', '2017-03-27 17:07:18', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129218', '10008', '2017-03-27 17:07:40', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129219', '10006', '2017-03-27 17:08:01', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129220', '10006', '2017-03-27 17:14:57', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129221', '10003', '2017-03-27 17:15:30', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129222', '10007', '2017-03-27 17:16:10', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129223', '10008', '2017-03-27 17:16:55', '114.222.189.69');
INSERT INTO `agent_login_log` VALUES ('129224', '10006', '2017-04-06 11:59:59', '117.89.51.149');
INSERT INTO `agent_login_log` VALUES ('129225', '10006', '2017-04-07 14:31:42', '49.77.229.187');
INSERT INTO `agent_login_log` VALUES ('129226', '10008', '2017-04-07 14:41:38', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129227', '10007', '2017-04-07 14:42:45', '49.77.229.187');
INSERT INTO `agent_login_log` VALUES ('129228', '10006', '2017-04-07 14:43:09', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129229', '10006', '2017-04-07 14:46:49', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129230', '10008', '2017-04-07 14:46:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129231', '10007', '2017-04-07 14:47:03', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129232', '10007', '2017-04-07 14:49:53', '49.77.229.187');
INSERT INTO `agent_login_log` VALUES ('129233', '10006', '2017-04-07 14:50:50', '113.76.150.252');
INSERT INTO `agent_login_log` VALUES ('129234', '10006', '2017-04-07 15:17:35', '113.106.108.66');
INSERT INTO `agent_login_log` VALUES ('129235', '10006', '2017-04-07 16:30:03', '113.76.150.252');
INSERT INTO `agent_login_log` VALUES ('129236', '10006', '2017-04-07 16:41:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129237', '10008', '2017-04-07 16:42:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129238', '10006', '2017-04-07 17:17:49', '113.76.150.252');
INSERT INTO `agent_login_log` VALUES ('129239', '10006', '2017-04-07 17:33:26', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129240', '10006', '2017-04-07 23:59:29', '116.28.2.106');
INSERT INTO `agent_login_log` VALUES ('129241', '10006', '2017-04-08 22:41:01', '116.28.2.106');
INSERT INTO `agent_login_log` VALUES ('129242', '10006', '2017-04-10 09:26:36', '113.76.149.209');
INSERT INTO `agent_login_log` VALUES ('129243', '10007', '2017-04-11 14:06:21', '117.89.48.184');
INSERT INTO `agent_login_log` VALUES ('129244', '10007', '2017-04-27 11:21:25', '117.89.48.195');
INSERT INTO `agent_login_log` VALUES ('129245', '10006', '2017-04-27 11:22:24', '117.89.48.195');
INSERT INTO `agent_login_log` VALUES ('129246', '10008', '2017-04-27 11:23:13', '117.89.48.195');
INSERT INTO `agent_login_log` VALUES ('129247', '10006', '2017-04-27 11:23:36', '117.89.48.195');
INSERT INTO `agent_login_log` VALUES ('129248', '10007', '2017-04-27 11:23:55', '117.89.48.195');
INSERT INTO `agent_login_log` VALUES ('129249', '10008', '2017-05-08 13:23:26', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129250', '10009', '2017-05-08 13:26:39', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129251', '10006', '2017-05-08 13:26:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129252', '10007', '2017-05-08 13:27:17', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129253', '10010', '2017-05-08 13:37:29', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129254', '10010', '2017-05-08 13:53:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129255', '10009', '2017-05-08 14:00:31', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129256', '10009', '2017-05-08 14:01:15', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129257', '10006', '2017-05-08 14:12:42', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129258', '10010', '2017-05-08 14:19:04', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129259', '10010', '2017-05-08 14:23:22', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129260', '10007', '2017-05-08 14:34:07', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129261', '10008', '2017-05-08 14:34:23', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129262', '10006', '2017-05-08 14:34:49', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129263', '10008', '2017-05-08 15:04:13', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129264', '10009', '2017-05-08 15:05:40', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129265', '10006', '2017-05-08 15:15:54', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129266', '10006', '2017-05-08 15:23:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129267', '10007', '2017-05-08 15:24:59', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129268', '10007', '2017-05-08 15:25:18', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129269', '10009', '2017-05-08 15:25:29', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129270', '10010', '2017-05-08 15:26:44', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129271', '10008', '2017-05-08 15:37:31', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129272', '10006', '2017-05-08 16:02:17', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129273', '10009', '2017-05-08 16:06:58', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129274', '10006', '2017-05-08 16:20:31', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129275', '10008', '2017-05-08 16:20:46', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129276', '10007', '2017-05-08 16:33:58', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129277', '10006', '2017-05-08 16:34:21', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129278', '10008', '2017-05-08 16:42:17', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129279', '10006', '2017-05-08 16:57:57', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129280', '10008', '2017-05-08 17:00:50', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129281', '10007', '2017-05-08 17:10:24', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129282', '10008', '2017-05-08 17:20:57', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129283', '10007', '2017-05-08 17:22:03', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129284', '10007', '2017-05-08 17:23:03', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129285', '10010', '2017-05-08 17:23:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129286', '10006', '2017-05-08 17:32:23', '49.77.239.57');
INSERT INTO `agent_login_log` VALUES ('129287', '10007', '2017-05-08 17:55:44', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129288', '10008', '2017-05-08 18:13:38', '49.77.228.227');
INSERT INTO `agent_login_log` VALUES ('129289', '10007', '2017-05-09 09:42:05', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129290', '10008', '2017-05-09 09:42:50', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129291', '10006', '2017-05-09 09:47:02', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129292', '10006', '2017-05-09 11:32:17', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129293', '10007', '2017-05-09 11:32:42', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129294', '10008', '2017-05-09 11:32:57', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129295', '10009', '2017-05-09 11:33:10', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129296', '10010', '2017-05-09 14:02:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129297', '10006', '2017-05-09 14:46:13', '49.77.226.6');
INSERT INTO `agent_login_log` VALUES ('129298', '10007', '2017-05-09 14:56:20', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129299', '10009', '2017-05-09 14:57:41', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129300', '10006', '2017-05-09 14:58:59', '49.77.228.4');
INSERT INTO `agent_login_log` VALUES ('129301', '10007', '2017-05-09 15:10:38', '49.77.226.6');
INSERT INTO `agent_login_log` VALUES ('129302', '10007', '2017-05-09 17:31:03', '49.77.226.6');
INSERT INTO `agent_login_log` VALUES ('129303', '10006', '2017-05-09 17:31:23', '49.77.226.6');
INSERT INTO `agent_login_log` VALUES ('129304', '10010', '2017-05-09 21:20:26', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129305', '10006', '2017-05-09 22:29:15', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129306', '10007', '2017-05-09 22:29:53', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129307', '10008', '2017-05-09 22:30:33', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129308', '10009', '2017-05-09 22:30:53', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129309', '10010', '2017-05-09 22:51:38', '222.95.136.114');
INSERT INTO `agent_login_log` VALUES ('129310', '10006', '2017-05-10 09:16:18', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129311', '10010', '2017-05-10 10:23:24', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129312', '10006', '2017-05-10 10:47:13', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129313', '10007', '2017-05-10 10:47:31', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129314', '10008', '2017-05-10 10:47:43', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129315', '10009', '2017-05-10 10:48:00', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129316', '10008', '2017-05-10 10:48:14', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129317', '10009', '2017-05-10 10:50:08', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129318', '10007', '2017-05-10 13:23:18', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129319', '10006', '2017-05-10 13:24:04', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129320', '10007', '2017-05-10 13:25:45', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129321', '10010', '2017-05-10 14:03:07', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129322', '10006', '2017-05-10 14:18:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129323', '10007', '2017-05-10 14:18:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129324', '10008', '2017-05-10 14:19:24', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129325', '10009', '2017-05-10 14:20:41', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129326', '10010', '2017-05-10 14:21:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129327', '10006', '2017-05-10 14:23:13', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129328', '10007', '2017-05-10 14:59:19', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129329', '10009', '2017-05-10 15:09:06', '222.95.85.26');
INSERT INTO `agent_login_log` VALUES ('129330', '10006', '2017-05-10 15:27:49', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129331', '10007', '2017-05-10 15:28:02', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129332', '10008', '2017-05-10 15:28:23', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129333', '10009', '2017-05-10 15:29:48', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129334', '10010', '2017-05-10 15:31:50', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129335', '10010', '2017-05-10 23:33:03', '121.237.73.27');
INSERT INTO `agent_login_log` VALUES ('129336', '10006', '2017-05-11 09:01:13', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129337', '10007', '2017-05-11 09:03:40', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129338', '10008', '2017-05-11 09:04:19', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129339', '10009', '2017-05-11 09:05:09', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129340', '10010', '2017-05-11 09:05:20', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129341', '10011', '2017-05-11 09:06:33', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129342', '10010', '2017-05-11 10:22:50', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129343', '10009', '2017-05-11 10:35:59', '117.89.51.108');
INSERT INTO `agent_login_log` VALUES ('129344', '10008', '2017-05-11 10:40:33', '117.89.51.108');
INSERT INTO `agent_login_log` VALUES ('129345', '10007', '2017-05-11 10:41:44', '117.89.51.108');
INSERT INTO `agent_login_log` VALUES ('129346', '10006', '2017-05-11 10:54:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129347', '10007', '2017-05-11 10:57:02', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129348', '10008', '2017-05-11 10:57:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129349', '10009', '2017-05-11 10:58:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129350', '10006', '2017-05-11 10:59:31', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129351', '10007', '2017-05-11 10:59:48', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129352', '10008', '2017-05-11 11:00:16', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129353', '10007', '2017-05-11 11:09:16', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129354', '10006', '2017-05-11 11:15:09', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129355', '10007', '2017-05-11 11:16:25', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129356', '10008', '2017-05-11 11:16:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129357', '10007', '2017-05-11 11:18:01', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129358', '10006', '2017-05-11 11:18:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129359', '10009', '2017-05-11 15:36:04', '117.89.51.108');
INSERT INTO `agent_login_log` VALUES ('129360', '10007', '2017-05-11 16:10:38', '117.89.48.98');
INSERT INTO `agent_login_log` VALUES ('129361', '10010', '2017-05-11 23:31:45', '114.221.111.45');
INSERT INTO `agent_login_log` VALUES ('129362', '10006', '2017-05-12 11:27:55', '117.89.51.108');
INSERT INTO `agent_login_log` VALUES ('129363', '10010', '2017-05-15 13:58:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129364', '10010', '2017-05-15 19:53:38', '49.74.227.159');
INSERT INTO `agent_login_log` VALUES ('129365', '10010', '2017-05-15 22:43:46', '49.74.227.159');
INSERT INTO `agent_login_log` VALUES ('129366', '10009', '2017-05-16 13:17:42', '49.77.227.120');
INSERT INTO `agent_login_log` VALUES ('129367', '10007', '2017-05-16 13:32:34', '49.77.229.139');
INSERT INTO `agent_login_log` VALUES ('129368', '10007', '2017-05-16 13:32:46', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129369', '10010', '2017-05-16 17:58:04', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129370', '10010', '2017-05-17 10:13:50', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129371', '10010', '2017-05-17 11:27:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129372', '10010', '2017-05-18 14:00:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129373', '10010', '2017-05-22 14:17:09', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129374', '10010', '2017-05-23 15:45:01', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129375', '10010', '2017-05-24 14:03:27', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129376', '10010', '2017-06-01 17:22:42', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129377', '10010', '2017-06-02 17:12:14', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129378', '10010', '2017-06-09 16:27:34', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129379', '10010', '2017-06-19 15:55:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129380', '10010', '2017-06-23 15:45:07', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129381', '10006', '2017-06-29 13:28:04', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129382', '10006', '2017-06-29 13:29:42', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129383', '10011', '2017-06-29 13:30:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129384', '10011', '2017-06-29 13:37:20', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129385', '10006', '2017-06-29 17:23:57', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129386', '10007', '2017-06-29 17:27:01', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129387', '10008', '2017-06-29 17:27:50', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129388', '10010', '2017-06-30 10:08:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129389', '10011', '2017-06-30 13:37:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129390', '10013', '2017-06-30 14:11:24', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129391', '10006', '2017-06-30 14:13:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129392', '10007', '2017-06-30 14:14:20', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129393', '10008', '2017-06-30 14:14:39', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129394', '10009', '2017-06-30 14:14:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129395', '10010', '2017-06-30 14:15:18', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129396', '10011', '2017-07-01 14:08:00', '121.237.69.102');
INSERT INTO `agent_login_log` VALUES ('129397', '10010', '2017-07-03 09:35:42', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129398', '10011', '2017-07-03 11:26:53', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129399', '10011', '2017-07-03 15:53:26', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129400', '10011', '2017-07-03 18:12:29', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129401', '10011', '2017-07-03 21:32:54', '180.111.173.219');
INSERT INTO `agent_login_log` VALUES ('129402', '10011', '2017-07-04 09:01:54', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129403', '10011', '2017-07-04 13:35:02', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129404', '10011', '2017-07-04 15:08:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129405', '10011', '2017-07-04 17:58:26', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129406', '10011', '2017-07-04 23:29:26', '121.237.57.105');
INSERT INTO `agent_login_log` VALUES ('129407', '10011', '2017-07-05 00:57:50', '121.237.57.105');
INSERT INTO `agent_login_log` VALUES ('129408', '10011', '2017-07-05 07:25:59', '121.237.57.105');
INSERT INTO `agent_login_log` VALUES ('129409', '10011', '2017-07-05 09:23:04', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129410', '10011', '2017-07-05 10:52:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129411', '10011', '2017-07-05 11:03:22', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129412', '10006', '2017-07-05 13:42:03', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129413', '10010', '2017-07-05 14:05:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129414', '10011', '2017-07-05 16:52:54', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129415', '10011', '2017-07-06 00:12:27', '121.237.57.12');
INSERT INTO `agent_login_log` VALUES ('129416', '10011', '2017-07-06 09:06:39', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129417', '10011', '2017-07-06 13:40:55', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129418', '10010', '2017-07-06 14:17:22', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129419', '10011', '2017-07-06 15:17:29', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129420', '10011', '2017-07-06 15:25:16', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129421', '10006', '2017-07-06 15:32:33', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129422', '10011', '2017-07-06 16:32:25', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129423', '10010', '2017-07-06 17:25:28', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129424', '10011', '2017-07-06 18:21:58', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129425', '10011', '2017-07-06 21:23:06', '180.110.87.239');
INSERT INTO `agent_login_log` VALUES ('129426', '10010', '2017-07-06 22:49:20', '58.212.55.7');
INSERT INTO `agent_login_log` VALUES ('129427', '10011', '2017-07-07 08:59:51', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129428', '10011', '2017-07-07 10:00:38', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129429', '10010', '2017-07-07 10:01:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129430', '10011', '2017-07-07 13:39:55', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129431', '10010', '2017-07-07 13:53:21', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129432', '10010', '2017-07-07 14:10:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129433', '10011', '2017-07-08 10:09:43', '180.110.227.252');
INSERT INTO `agent_login_log` VALUES ('129434', '10011', '2017-07-08 12:45:20', '180.110.227.252');
INSERT INTO `agent_login_log` VALUES ('129435', '10011', '2017-07-08 19:11:38', '114.221.27.54');
INSERT INTO `agent_login_log` VALUES ('129436', '10011', '2017-07-08 21:46:02', '114.221.27.54');
INSERT INTO `agent_login_log` VALUES ('129437', '10011', '2017-07-09 00:14:07', '114.221.27.54');
INSERT INTO `agent_login_log` VALUES ('129438', '10011', '2017-07-09 09:43:09', '114.221.27.54');
INSERT INTO `agent_login_log` VALUES ('129439', '10011', '2017-07-09 15:14:52', '114.221.27.54');
INSERT INTO `agent_login_log` VALUES ('129440', '10011', '2017-07-11 08:59:19', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129441', '10011', '2017-07-11 11:33:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129442', '10011', '2017-07-11 14:36:38', '121.237.59.225');
INSERT INTO `agent_login_log` VALUES ('129443', '10011', '2017-07-11 20:21:42', '121.237.59.225');
INSERT INTO `agent_login_log` VALUES ('129444', '10011', '2017-07-12 14:04:48', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129445', '10011', '2017-07-12 15:21:04', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129446', '10011', '2017-07-13 07:29:04', '121.229.87.158');
INSERT INTO `agent_login_log` VALUES ('129447', '10011', '2017-07-13 10:48:33', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129448', '10011', '2017-07-13 11:29:36', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129449', '10011', '2017-07-13 14:47:40', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129450', '10011', '2017-07-13 16:57:53', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129451', '10011', '2017-07-13 19:44:00', '121.237.72.85');
INSERT INTO `agent_login_log` VALUES ('129452', '10010', '2017-07-17 14:59:38', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129453', '10011', '2017-07-18 17:22:18', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129454', '10011', '2017-07-19 10:39:01', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129455', '10011', '2017-07-19 16:19:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129456', '10011', '2017-07-21 20:31:49', '121.225.76.209');
INSERT INTO `agent_login_log` VALUES ('129457', '10011', '2017-07-24 10:22:03', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129458', '10011', '2017-07-24 13:59:19', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129459', '10010', '2017-07-24 16:24:31', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129460', '10011', '2017-07-26 09:52:10', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129461', '10010', '2017-07-31 11:10:38', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129462', '10011', '2017-07-31 17:47:45', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129463', '10006', '2017-08-02 14:56:12', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129464', '10010', '2017-08-03 13:28:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129465', '10010', '2017-08-03 19:37:30', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129466', '10010', '2017-08-04 15:26:21', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129467', '10011', '2017-08-07 11:01:48', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129468', '10011', '2017-08-07 15:56:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129469', '10011', '2017-08-07 15:56:11', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129470', '10010', '2017-08-16 09:55:37', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129471', '10011', '2017-08-24 16:57:58', '114.221.193.202');
INSERT INTO `agent_login_log` VALUES ('129472', '10011', '2017-08-25 13:24:30', '114.221.193.202');
INSERT INTO `agent_login_log` VALUES ('129473', '10011', '2017-08-25 17:44:02', '114.221.193.202');
INSERT INTO `agent_login_log` VALUES ('129474', '10011', '2017-08-29 10:07:24', '49.65.109.210');
INSERT INTO `agent_login_log` VALUES ('129475', '10011', '2017-08-29 10:50:17', '49.65.109.210');
INSERT INTO `agent_login_log` VALUES ('129476', '10011', '2017-09-05 11:00:36', '121.225.211.119');
INSERT INTO `agent_login_log` VALUES ('129477', '10011', '2017-09-14 15:50:39', '49.77.234.237');
INSERT INTO `agent_login_log` VALUES ('129478', '10020', '2017-09-26 15:10:08', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129479', '10011', '2017-09-26 15:55:36', '180.102.200.23');
INSERT INTO `agent_login_log` VALUES ('129480', '10020', '2017-09-26 15:57:52', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129481', '10020', '2017-09-27 09:50:44', '58.240.26.114');
INSERT INTO `agent_login_log` VALUES ('129482', '10020', '2017-10-13 13:51:35', '49.77.234.240');
INSERT INTO `agent_login_log` VALUES ('129483', '10020', '2017-10-13 16:41:43', '49.77.234.240');
INSERT INTO `agent_login_log` VALUES ('129484', '10021', '2017-11-03 15:03:48', '180.110.208.25');

-- ----------------------------
-- Table structure for agent_pay
-- ----------------------------
DROP TABLE IF EXISTS `agent_pay`;
CREATE TABLE `agent_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `site_id` int(11) DEFAULT NULL COMMENT '广告位ID',
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  `price` float NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '广告类型：1:弹窗2:横幅3:漂浮4:文字链5:其它6:小游戏',
  `state` tinyint(4) NOT NULL COMMENT '0:未支付1:支付',
  `pay_way` tinyint(4) NOT NULL COMMENT '1:cpm2:cpc3:cpa4:包月5:免费6:cps',
  `pay_date` datetime NOT NULL,
  `memo` text,
  `add_type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0手工录入 1Excel导入',
  `s_e_date` varchar(50) DEFAULT NULL COMMENT '包月区间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of agent_pay
-- ----------------------------

-- ----------------------------
-- Table structure for agent_site
-- ----------------------------
DROP TABLE IF EXISTS `agent_site`;
CREATE TABLE `agent_site` (
  `site_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '成员ID',
  `agent_id` int(11) NOT NULL DEFAULT '0' COMMENT '公会ID',
  `author` varchar(60) DEFAULT NULL COMMENT '成员名称',
  `aAccount` varchar(100) DEFAULT NULL COMMENT '公会成员登录账号',
  `aPass` varchar(32) DEFAULT '123456' COMMENT '公会成员登录密码',
  `loginIp` varchar(32) DEFAULT NULL COMMENT '登陆ip',
  `url` varchar(50) NOT NULL DEFAULT '',
  `loginAddress` varchar(50) DEFAULT NULL COMMENT 'IP地址',
  `logincount` int(10) NOT NULL DEFAULT '0' COMMENT '登录次数',
  `loginTime` datetime DEFAULT NULL COMMENT '上次登录时间',
  `agent_type` int(11) NOT NULL DEFAULT '0' COMMENT ' 渠道类型',
  `adtype` tinyint(2) NOT NULL DEFAULT '1' COMMENT '广告类型',
  `pay_way` tinyint(2) NOT NULL DEFAULT '1' COMMENT '付费类型',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态(0:未审核1:已审核)',
  PRIMARY KEY (`site_id`),
  KEY `url` (`url`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=10110 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of agent_site
-- ----------------------------
INSERT INTO `agent_site` VALUES ('100', '100', '官网', '91yxq', '91yxq111111', '183.54.201.204', '', '广东广州', '8', '2016-03-03 10:39:38', '0', '1', '1', '2015-11-30 10:21:15', '1');
INSERT INTO `agent_site` VALUES ('10008', '10006', 'member1', 'account1', '111111', '58.240.26.114', '', '江苏南京', '8', '2017-09-30 09:36:10', '0', '1', '1', '2017-03-21 09:37:26', '1');
INSERT INTO `agent_site` VALUES ('10009', '10006', 'member2', 'account2', '111111', '58.240.26.114', '', '江苏南京', '5', '2017-08-03 13:28:19', '0', '1', '1', '2017-03-21 09:38:04', '1');
INSERT INTO `agent_site` VALUES ('10010', '10006', 'member3', 'account3', '111111', '58.240.26.114', '', '江苏南京', '2', '2017-03-21 11:17:30', '0', '1', '1', '2017-03-21 09:38:25', '1');
INSERT INTO `agent_site` VALUES ('10011', '10007', 'member4', 'account4', '111111', '58.240.26.114', '', '江苏南京', '2', '2017-03-21 11:17:48', '0', '1', '1', '2017-03-21 09:38:41', '1');
INSERT INTO `agent_site` VALUES ('10012', '10007', 'member5', 'account5', '111111', '58.240.26.114', '', '江苏南京', '2', '2017-07-10 16:09:31', '0', '1', '1', '2017-03-21 09:39:00', '1');
INSERT INTO `agent_site` VALUES ('10013', '10007', 'member6', 'account6', '111111', '58.240.26.114', '', '江苏南京', '1', '2017-03-21 10:33:54', '0', '1', '1', '2017-03-21 09:39:18', '1');
INSERT INTO `agent_site` VALUES ('10014', '10008', 'member7', 'account7', '111111', null, '', null, '0', null, '0', '1', '1', '2017-03-21 10:53:16', '1');
INSERT INTO `agent_site` VALUES ('10015', '10008', 'member8', 'account8', '111111', null, '', null, '0', null, '0', '1', '1', '2017-03-21 10:53:34', '1');
INSERT INTO `agent_site` VALUES ('10016', '10008', 'member9', 'account9', '111111', null, '', null, '0', null, '0', '1', '1', '2017-03-21 10:53:59', '1');
INSERT INTO `agent_site` VALUES ('10017', '10009', 'member10', 'account10', '111111', '58.240.26.114', '', '江苏南京', '1', '2017-03-23 13:49:45', '0', '1', '1', '2017-03-23 13:42:34', '1');
INSERT INTO `agent_site` VALUES ('10018', '10009', 'member11', 'account11', '111111', null, '', null, '0', null, '0', '1', '1', '2017-03-23 13:42:54', '1');
INSERT INTO `agent_site` VALUES ('10019', '10009', 'member12', 'account12', '111111', null, '', null, '0', null, '0', '1', '1', '2017-03-23 13:43:11', '1');
INSERT INTO `agent_site` VALUES ('10033', '10006', 'member13', 'account13', '111111', null, '', null, '0', null, '0', '1', '1', '2017-04-07 15:03:52', '1');
INSERT INTO `agent_site` VALUES ('10034', '10007', 'member14', 'account14', '111111', null, '', null, '0', null, '0', '1', '1', '2017-04-07 15:04:09', '1');
INSERT INTO `agent_site` VALUES ('10035', '10008', 'member15', 'account15', '111111', null, '', null, '0', null, '0', '1', '1', '2017-04-07 15:04:25', '1');
INSERT INTO `agent_site` VALUES ('10036', '10006', 'member16', 'account16', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:20:20', '1');
INSERT INTO `agent_site` VALUES ('10037', '10006', 'member17', 'account17', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:20:39', '1');
INSERT INTO `agent_site` VALUES ('10038', '10007', 'member18', 'account18', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:20:55', '1');
INSERT INTO `agent_site` VALUES ('10039', '10007', 'member19', 'account19', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:21:12', '1');
INSERT INTO `agent_site` VALUES ('10040', '10008', 'member20', 'account20', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:21:27', '1');
INSERT INTO `agent_site` VALUES ('10041', '10008', 'member21', 'account21', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:21:44', '1');
INSERT INTO `agent_site` VALUES ('10042', '10009', 'member22', 'account22', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 10:57:48', '1');
INSERT INTO `agent_site` VALUES ('10043', '10009', 'member23', 'account23', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 11:00:56', '1');
INSERT INTO `agent_site` VALUES ('10044', '10009', 'member24', 'account24', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-08 11:01:12', '1');
INSERT INTO `agent_site` VALUES ('10045', '10010', 'member25', 'account25', '111111', '58.240.26.114', '', '江苏南京', '3', '2017-08-04 15:28:18', '0', '1', '1', '2017-05-08 13:33:09', '1');
INSERT INTO `agent_site` VALUES ('10046', '10006', 'member26', 'account26', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:13:48', '1');
INSERT INTO `agent_site` VALUES ('10047', '10006', 'member27', 'account27', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:14:05', '1');
INSERT INTO `agent_site` VALUES ('10048', '10006', 'member28', 'account28', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:14:22', '1');
INSERT INTO `agent_site` VALUES ('10049', '10007', 'member29', 'account29', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:14:38', '1');
INSERT INTO `agent_site` VALUES ('10050', '10007', 'member30', 'account30', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:15:05', '1');
INSERT INTO `agent_site` VALUES ('10051', '10007', 'member31', 'account31', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:15:22', '1');
INSERT INTO `agent_site` VALUES ('10052', '10008', 'member32', 'account32', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:15:41', '1');
INSERT INTO `agent_site` VALUES ('10053', '10008', 'member33', 'account33', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:15:56', '1');
INSERT INTO `agent_site` VALUES ('10054', '10008', 'member34', 'account34', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:16:18', '1');
INSERT INTO `agent_site` VALUES ('10055', '10009', 'member35', 'account35', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:16:34', '1');
INSERT INTO `agent_site` VALUES ('10056', '10009', 'member36', 'account36', '111111', null, '', null, '0', null, '0', '1', '1', '2017-05-09 09:16:51', '1');
INSERT INTO `agent_site` VALUES ('10057', '10009', 'member37', 'account37', '111111', '58.240.26.114', '', '江苏南京', '1', '2017-07-05 09:54:18', '0', '1', '1', '2017-05-09 09:17:07', '1');
INSERT INTO `agent_site` VALUES ('10058', '10011', 'member38', 'account38', '111111', '58.240.26.114', '', '江苏南京', '1', '2017-08-02 14:57:19', '0', '1', '1', '2017-05-10 10:45:43', '1');
INSERT INTO `agent_site` VALUES ('10059', '10011', '10001', 'rouernern', 'wm1111', '58.240.26.114', '', '江苏南京', '12', '2017-08-07 15:57:11', '0', '1', '1', '2017-06-29 13:31:46', '1');
INSERT INTO `agent_site` VALUES ('10060', '10011', '腾辉', '10010', '123789', '121.237.69.102', '', '江苏南京', '9', '2017-07-01 14:06:40', '0', '1', '1', '2017-06-29 13:42:04', '1');
INSERT INTO `agent_site` VALUES ('10061', '10013', 'member39', 'account39', '111111', '58.240.26.114', '', '江苏南京', '2', '2017-06-30 13:58:00', '0', '1', '1', '2017-06-30 11:13:56', '1');
INSERT INTO `agent_site` VALUES ('10062', '10013', '10002', '邬亮', '5822089', null, '', null, '0', null, '0', '1', '1', '2017-06-30 14:13:02', '1');
INSERT INTO `agent_site` VALUES ('10063', '10011', '李信', 'lixin1213', '771213', '58.212.55.34', '', '江苏南京', '4', '2017-07-10 12:17:39', '0', '1', '1', '2017-07-03 12:52:40', '1');
INSERT INTO `agent_site` VALUES ('10064', '10011', '阳光', 'yangguang', '123456', '112.96.164.80', '', '广东', '4', '2017-07-04 09:40:42', '0', '1', '1', '2017-07-03 12:55:26', '1');
INSERT INTO `agent_site` VALUES ('10065', '10011', '天下', 'tianxia', '5822089', '121.237.57.105', '', '江苏南京', '2', '2017-07-04 23:27:07', '0', '1', '1', '2017-07-03 12:56:04', '1');
INSERT INTO `agent_site` VALUES ('10066', '10011', '测试', '15895979744', '5822089', '58.240.26.114', '', '江苏南京', '16', '2017-07-31 17:55:26', '0', '1', '1', '2017-07-03 14:17:19', '1');
INSERT INTO `agent_site` VALUES ('10067', '10011', '千叶玫瑰', 'qq404289613', 'lxflxf123', '58.255.229.2', '', '广东茂名', '55', '2017-11-21 18:14:08', '0', '1', '1', '2017-07-04 10:03:36', '1');
INSERT INTO `agent_site` VALUES ('10068', '10011', '乱世', 'a741490861', '2543925', '175.4.254.106', '', '湖南郴州', '2', '2017-08-21 16:56:57', '0', '1', '1', '2017-07-06 14:00:12', '1');
INSERT INTO `agent_site` VALUES ('10069', '10011', '夕阳', 'zeng826927', '000000', '106.84.142.24', '', '重庆重庆', '17', '2017-07-21 17:37:26', '0', '1', '1', '2017-07-12 15:22:14', '1');
INSERT INTO `agent_site` VALUES ('10070', '10014', 'bengbeng', 'bengbeng', '111111', null, '', null, '0', null, '0', '1', '1', '2017-07-14 14:15:33', '1');
INSERT INTO `agent_site` VALUES ('10071', '10011', 'mly', 'mly920514', 'shi520', '59.56.7.170', '', '福建福州', '2', '2017-07-19 16:59:43', '0', '1', '1', '2017-07-18 17:45:08', '1');
INSERT INTO `agent_site` VALUES ('10072', '10011', 'zhao', 'zhaohuabing', 'huabing123..', '223.102.119.141', '', '辽宁鞍山', '5', '2017-07-25 15:00:03', '0', '1', '1', '2017-07-21 20:32:27', '1');
INSERT INTO `agent_site` VALUES ('10073', '10011', 'C', 'c1002063457', '123qweasd', '1.181.177.114', '', '内蒙古赤峰', '1', '2017-07-24 13:32:09', '0', '1', '1', '2017-07-24 10:23:45', '1');
INSERT INTO `agent_site` VALUES ('10074', '10015', 'kuailezhuan', 'kuailezhuan', '111111', null, '', null, '0', null, '0', '1', '1', '2017-07-25 16:11:36', '1');
INSERT INTO `agent_site` VALUES ('10075', '10011', 'Z', 'zhuguocheng', '123456', '113.247.54.23', '', '湖南长沙', '3', '2017-08-01 18:43:21', '0', '1', '1', '2017-07-31 17:48:19', '1');
INSERT INTO `agent_site` VALUES ('10076', '10016', 'juxiangyou', 'juxiangyou', '111111', null, '', null, '0', null, '0', '1', '1', '2017-08-04 16:07:26', '1');
INSERT INTO `agent_site` VALUES ('10079', '10020', 'mocuz_10020', 'mocuz_10020', 'kj5sdf445sd87f!@#', null, '', null, '0', null, '0', '1', '1', '2017-08-07 15:31:09', '1');
INSERT INTO `agent_site` VALUES ('10082', '10017', '24quba', '24quba', '111111', null, '', null, '0', null, '0', '1', '1', '2017-08-08 14:33:08', '1');
INSERT INTO `agent_site` VALUES ('10087', '10020', 'mocuz_339157', 'mocuz_339157', 'kj5sdf445sd87f!@#', '58.240.26.114', 'http://demo.mocuz.com/', '江苏南京', '1', '2017-08-28 17:07:16', '0', '1', '1', '2017-08-14 11:23:01', '1');
INSERT INTO `agent_site` VALUES ('10088', '10020', '168_985248', '168_985248', 'kj5sdf445sd87f!@#', null, 'http://192.168.40.37/upload/', null, '0', null, '0', '1', '1', '2017-08-14 11:23:16', '1');
INSERT INTO `agent_site` VALUES ('10089', '10025', 'youyiwang', 'youyiwang', '111111', null, '', null, '0', null, '0', '1', '1', '2017-08-24 10:47:36', '1');
INSERT INTO `agent_site` VALUES ('10090', '10026', 'shitoucun', 'shitoucun', '111111', null, '', null, '0', null, '0', '1', '1', '2017-08-24 10:47:54', '1');
INSERT INTO `agent_site` VALUES ('10091', '10011', '启点', '启点', 'q123123', '121.61.106.178', '', '湖北咸宁', '2', '2017-08-24 16:59:54', '0', '1', '1', '2017-08-24 16:59:04', '1');
INSERT INTO `agent_site` VALUES ('10092', '10027', 'tiantianzuan', 'tiantianzuan', '111111', null, '', null, '0', null, '0', '1', '1', '2017-08-25 10:54:46', '1');
INSERT INTO `agent_site` VALUES ('10093', '10020', '_149652', '_149652', 'kj5sdf445sd87f!@#', '58.240.26.114', 'http://localhost/upload/', '江苏南京', '1', '2017-08-28 17:02:05', '0', '1', '1', '2017-08-28 15:47:51', '1');
INSERT INTO `agent_site` VALUES ('10094', '10011', '张先生', '百强', '123456', null, '', null, '0', null, '0', '1', '1', '2017-08-29 10:51:07', '1');
INSERT INTO `agent_site` VALUES ('10095', '10028', 'ledouwan', 'ledouwan', '111111', '58.240.26.114', '', '江苏南京', '1', '2017-11-09 13:52:03', '0', '1', '1', '2017-09-13 16:14:29', '1');
INSERT INTO `agent_site` VALUES ('10096', '10029', 'jiquwang', 'jiquwang', '111111', null, '', null, '0', null, '0', '1', '1', '2017-09-13 16:15:50', '1');
INSERT INTO `agent_site` VALUES ('10097', '10020', 'ynian_280680', 'ynian_280680', 'kj5sdf445sd87f!@#', null, 'http://www.ynian.com/', null, '0', null, '0', '1', '1', '2017-09-25 16:55:33', '1');
INSERT INTO `agent_site` VALUES ('10098', '10020', 'gsxbbs_690583', 'gsxbbs_690583', 'kj5sdf445sd87f!@#', null, 'http://www.gsxbbs.com/', null, '0', null, '0', '1', '1', '2017-09-28 17:58:19', '1');
INSERT INTO `agent_site` VALUES ('10099', '10020', 'qjbxw_39858', 'qjbxw_39858', 'kj5sdf445sd87f!@#', null, 'http://www.qjbxw.com/', null, '0', null, '0', '1', '1', '2017-10-09 15:53:59', '1');
INSERT INTO `agent_site` VALUES ('10100', '10020', '211600_711555', '211600_711555', 'kj5sdf445sd87f!@#', null, 'http://bbs.211600.com/', null, '0', null, '0', '1', '1', '2017-10-11 14:26:28', '1');
INSERT INTO `agent_site` VALUES ('10101', '10020', '211600_856260', '211600_856260', 'kj5sdf445sd87f!@#', null, 'http://home.211600.com/', null, '0', null, '0', '1', '1', '2017-10-11 14:27:37', '1');
INSERT INTO `agent_site` VALUES ('10102', '10020', 'songzi100_701438', 'songzi100_701438', 'kj5sdf445sd87f!@#', null, 'https://www.songzi100.com/', null, '0', null, '0', '1', '1', '2017-10-17 11:09:38', '1');
INSERT INTO `agent_site` VALUES ('10103', '10020', 'hongze_839469', 'hongze_839469', 'kj5sdf445sd87f!@#', null, 'http://www.hongze.net/', null, '0', null, '0', '1', '1', '2017-10-23 14:58:02', '1');
INSERT INTO `agent_site` VALUES ('10104', '10030', 'jujuwan', 'jujuwan', '111111', '58.240.26.114', '', '江苏南京', '2', '2017-11-09 14:40:26', '0', '1', '1', '2017-10-25 11:11:42', '1');
INSERT INTO `agent_site` VALUES ('10105', '10020', '_129275', '_129275', 'kj5sdf445sd87f!@#', null, 'http://localhost/discuz/', null, '0', null, '0', '1', '1', '2017-11-01 09:14:18', '1');
INSERT INTO `agent_site` VALUES ('10106', '10021', 'demo', 'demo', '111111', null, '', null, '0', null, '0', '1', '1', '2017-11-01 14:21:04', '1');
INSERT INTO `agent_site` VALUES ('10107', '10020', '0_262096', '0_262096', 'kj5sdf445sd87f!@#', null, 'http://127.0.0.1/bbs/', null, '0', null, '0', '1', '1', '2017-11-02 17:16:29', '1');
INSERT INTO `agent_site` VALUES ('10108', '10021', '王鸣', 'wangming', '123456', '58.240.26.114', '', '', '2', '2017-11-03 15:22:21', '0', '1', '1', '2017-11-03 14:58:54', '1');
INSERT INTO `agent_site` VALUES ('10109', '10032', 'yiruite', 'yiruite', '111111', null, '', null, '0', null, '0', '1', '1', '2017-11-09 10:01:26', '1');

-- ----------------------------
-- Table structure for Anchor_extend
-- ----------------------------
DROP TABLE IF EXISTS `Anchor_extend`;
CREATE TABLE `Anchor_extend` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `anchorname` varchar(50) NOT NULL COMMENT '主播名',
  `agent_id` int(10) NOT NULL COMMENT '公会ID',
  `game_id` int(10) NOT NULL COMMENT '游戏ID',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主播推广链接表';

-- ----------------------------
-- Records of Anchor_extend
-- ----------------------------

-- ----------------------------
-- Table structure for attachment
-- ----------------------------
DROP TABLE IF EXISTS `attachment`;
CREATE TABLE `attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` char(10) NOT NULL,
  `gid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `adid` char(10) NOT NULL,
  `filename` char(50) NOT NULL,
  `filepath` char(200) NOT NULL,
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL,
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uploadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of attachment
-- ----------------------------

-- ----------------------------
-- Table structure for ban_agent_game
-- ----------------------------
DROP TABLE IF EXISTS `ban_agent_game`;
CREATE TABLE `ban_agent_game` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL COMMENT '公会id',
  `pid` int(10) unsigned NOT NULL,
  `game_id` int(10) NOT NULL COMMENT '游戏id',
  `server_id` int(10) NOT NULL COMMENT '服区id',
  `auid` int(10) NOT NULL COMMENT '操作人id',
  `atime` datetime NOT NULL COMMENT '操作时间',
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=608 DEFAULT CHARSET=utf8 COMMENT='封链接';

-- ----------------------------
-- Records of ban_agent_game
-- ----------------------------

-- ----------------------------
-- Table structure for bound_user_toguild
-- ----------------------------
DROP TABLE IF EXISTS `bound_user_toguild`;
CREATE TABLE `bound_user_toguild` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(40) NOT NULL COMMENT '用户名',
  `regTime` int(10) NOT NULL COMMENT '该玩家注册时间',
  `agent_id` int(10) NOT NULL COMMENT '公会id',
  `game_id` int(10) NOT NULL COMMENT '游戏id',
  `server_id` int(10) NOT NULL COMMENT '服务器id',
  `uid` int(11) NOT NULL COMMENT '操作者id',
  `bTime` int(10) NOT NULL COMMENT '操作时间',
  `result` varchar(50) NOT NULL DEFAULT '1' COMMENT '操作结果，1表示绑定成功',
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='玩家绑定公会记录表';

-- ----------------------------
-- Records of bound_user_toguild
-- ----------------------------
INSERT INTO `bound_user_toguild` VALUES ('1', 'allen', '1490751049', '100', '1', '1', '123', '1500604558', '1');
INSERT INTO `bound_user_toguild` VALUES ('2', 'allen', '1490751049', '100', '4', '2', '123', '1500604621', '1');
INSERT INTO `bound_user_toguild` VALUES ('3', 'allen', '1490751049', '100', '1', '4', '123', '1500604658', '1');
INSERT INTO `bound_user_toguild` VALUES ('4', 'bangding', '1500622967', '100', '3', '12', '123', '1500623239', '1');
INSERT INTO `bound_user_toguild` VALUES ('5', 'jy02687972', '1500359548', '100', '2', '4', '123', '1501048671', '1');
INSERT INTO `bound_user_toguild` VALUES ('6', '18087403585', '1500895478', '100', '3', '20', '123', '1501324450', '1');
INSERT INTO `bound_user_toguild` VALUES ('7', 'qq15360514', '1500867123', '100', '3', '23', '123', '1501759390', '1');
INSERT INTO `bound_user_toguild` VALUES ('8', 'jinlong1977', '1501327193', '100', '3', '15', '123', '1501996611', '1');
INSERT INTO `bound_user_toguild` VALUES ('9', 'z8833580', '1501899595', '100', '3', '26', '123', '1502084551', '1');
INSERT INTO `bound_user_toguild` VALUES ('10', 'a8833580', '1501989083', '100', '3', '26', '123', '1502088220', '1');
INSERT INTO `bound_user_toguild` VALUES ('11', 'wuliao1233', '1500553848', '100', '2', '11', '123', '1502187982', '1');
INSERT INTO `bound_user_toguild` VALUES ('12', 'qianhu2', '1502682133', '100', '3', '36', '123', '1502683691', '1');
INSERT INTO `bound_user_toguild` VALUES ('13', 'a348743479', '1502758926', '100', '2', '36', '123', '1502803207', '1');
INSERT INTO `bound_user_toguild` VALUES ('14', 'hao860511', '1500983559', '100', '2', '16', '123', '1503183917', '1');
INSERT INTO `bound_user_toguild` VALUES ('15', 'cjc000', '1503295505', '100', '2', '43', '123', '1503304181', '1');
INSERT INTO `bound_user_toguild` VALUES ('16', 'x268068046', '1502744325', '100', '2', '49', '123', '1503902275', '1');
INSERT INTO `bound_user_toguild` VALUES ('17', 'huangke5896', '1505099678', '100', '3', '64', '123', '1505114808', '1');
INSERT INTO `bound_user_toguild` VALUES ('18', 'rs001ss', '1505112781', '100', '3', '64', '123', '1505181194', '1');
INSERT INTO `bound_user_toguild` VALUES ('19', 'yt111222', '1505130417', '100', '3', '64', '123', '1505286762', '1');
INSERT INTO `bound_user_toguild` VALUES ('20', 'qq970496900', '1508299103', '100', '3', '101', '123', '1508552083', '1');
INSERT INTO `bound_user_toguild` VALUES ('21', '99965030', '1508340768', '100', '3', '101', '123', '1508637406', '1');
INSERT INTO `bound_user_toguild` VALUES ('22', 'zouchuandong123', '1507380151', '100', '19', '9', '123', '1508726028', '1');
INSERT INTO `bound_user_toguild` VALUES ('23', 'zj5201314', '1507285736', '100', '19', '9', '123', '1508819580', '1');
INSERT INTO `bound_user_toguild` VALUES ('24', 'tianlang2111', '1511440080', '100', '3', '137', '123', '1511486943', '1');
INSERT INTO `bound_user_toguild` VALUES ('25', 'nbancc8723', '1512711269', '100', '3', '151', '123', '1512916450', '1');
INSERT INTO `bound_user_toguild` VALUES ('26', 'lxcy2018', '1512013047', '100', '3', '148', '123', '1512961300', '1');

-- ----------------------------
-- Table structure for game_aplication
-- ----------------------------
DROP TABLE IF EXISTS `game_aplication`;
CREATE TABLE `game_aplication` (
  `aid` int(12) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL COMMENT '申请的公会id',
  `game_id` int(10) NOT NULL COMMENT '申请的游戏id',
  `atime` int(10) NOT NULL COMMENT '申请时间',
  `check_uid` int(10) DEFAULT NULL COMMENT '审核人id',
  `ctime` int(10) DEFAULT NULL COMMENT '审核时间',
  `aresult` tinyint(1) NOT NULL DEFAULT '0' COMMENT '审核结果0为待审1为通过2为拒绝',
  KEY `aid` (`aid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='公会游戏申请推广表';

-- ----------------------------
-- Records of game_aplication
-- ----------------------------
INSERT INTO `game_aplication` VALUES ('1', '1', '3', '0', '0', '0', '1');
INSERT INTO `game_aplication` VALUES ('2', '121', '2', '1417435892', '0', '0', '0');
INSERT INTO `game_aplication` VALUES ('3', '643', '11', '1417436460', '0', '0', '0');
INSERT INTO `game_aplication` VALUES ('4', '100', '1', '1417493199', '23', '1417493218', '2');

-- ----------------------------
-- Table structure for game_support_account
-- ----------------------------
DROP TABLE IF EXISTS `game_support_account`;
CREATE TABLE `game_support_account` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '玩家账号',
  `adduser` int(10) NOT NULL COMMENT '添加人',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='扶持号添加表';

-- ----------------------------
-- Records of game_support_account
-- ----------------------------

-- ----------------------------
-- Table structure for game_support_account_apply
-- ----------------------------
DROP TABLE IF EXISTS `game_support_account_apply`;
CREATE TABLE `game_support_account_apply` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL COMMENT '充值账号',
  `game_id` int(10) NOT NULL COMMENT '游戏id',
  `server_id` int(10) NOT NULL COMMENT '游戏区服',
  `game_role` varchar(50) DEFAULT NULL COMMENT '角色名',
  `stime` int(10) NOT NULL COMMENT '充值起始时间',
  `etime` int(10) NOT NULL COMMENT '充值结束时间',
  `account` varchar(50) NOT NULL COMMENT '扶持账号',
  `uid` int(10) NOT NULL COMMENT '扶持账号UID',
  `gamerole` varchar(50) NOT NULL COMMENT '扶持角色',
  `gold` int(10) NOT NULL COMMENT '申请元宝',
  `applytime` int(11) NOT NULL COMMENT '申请时间',
  `agent_id` int(10) NOT NULL COMMENT '申请公会id',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `check_uid` int(10) NOT NULL COMMENT '审核人id',
  `check_time` int(10) NOT NULL COMMENT '审核时间',
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0为未审核，1为通过，2为拒绝',
  `reason` text COMMENT '拒绝理由',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='扶持号申请表';

-- ----------------------------
-- Records of game_support_account_apply
-- ----------------------------

-- ----------------------------
-- Table structure for inner_into
-- ----------------------------
DROP TABLE IF EXISTS `inner_into`;
CREATE TABLE `inner_into` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id,自增',
  `pt_id` int(10) NOT NULL COMMENT '平台id',
  `agent_id` int(10) NOT NULL COMMENT '公会',
  `game_id` int(10) NOT NULL COMMENT '游戏',
  `server` varchar(25) NOT NULL COMMENT '区服',
  `guildname` varchar(50) DEFAULT NULL COMMENT '军团长',
  `role_name` varchar(50) DEFAULT NULL COMMENT '角色',
  `money` int(10) NOT NULL COMMENT '金额',
  `payer_money` int(10) NOT NULL COMMENT '玩家充值',
  `into_time` date NOT NULL COMMENT '录入时间',
  `other` varchar(250) DEFAULT NULL COMMENT '其他说明',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=786 DEFAULT CHARSET=utf8 COMMENT='内充录入';

-- ----------------------------
-- Records of inner_into
-- ----------------------------

-- ----------------------------
-- Table structure for jie_into
-- ----------------------------
DROP TABLE IF EXISTS `jie_into`;
CREATE TABLE `jie_into` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `regmental` varchar(50) NOT NULL COMMENT '军团长',
  `colonel` varchar(50) NOT NULL COMMENT '团长',
  `pt_id` int(11) NOT NULL COMMENT '平台id',
  `game_id` int(11) NOT NULL COMMENT '游戏',
  `server_id` varchar(25) NOT NULL COMMENT '区服',
  `last_time` date DEFAULT NULL COMMENT '上次打款时间',
  `this_time` date NOT NULL COMMENT '这次打款时间',
  `money` int(11) NOT NULL COMMENT '充值金额',
  `pay_money` int(11) NOT NULL COMMENT '打款金额',
  `bank` varchar(50) NOT NULL COMMENT '银行',
  `bank_card` varchar(25) NOT NULL COMMENT '银行卡号',
  `bank_user` varchar(25) NOT NULL COMMENT '银行卡持有人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=353 DEFAULT CHARSET=utf8 COMMENT='团长结算录入';

-- ----------------------------
-- Records of jie_into
-- ----------------------------

-- ----------------------------
-- Table structure for leave_admin_group
-- ----------------------------
DROP TABLE IF EXISTS `leave_admin_group`;
CREATE TABLE `leave_admin_group` (
  `gId` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `gName` varchar(100) NOT NULL COMMENT '组名称',
  `cUser` int(10) NOT NULL DEFAULT '0' COMMENT '创建者id',
  `cTime` int(10) NOT NULL DEFAULT '0' COMMENT '创建人',
  `updUser` int(10) NOT NULL DEFAULT '0' COMMENT '最后修改者id',
  `updTime` int(10) NOT NULL DEFAULT '0' COMMENT '最后修改时间',
  `gState` varchar(1) NOT NULL DEFAULT '1' COMMENT '部门当前状态',
  `gGrants` text NOT NULL COMMENT '组权限',
  `px` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  PRIMARY KEY (`gId`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of leave_admin_group
-- ----------------------------

-- ----------------------------
-- Table structure for leave_admin_section
-- ----------------------------
DROP TABLE IF EXISTS `leave_admin_section`;
CREATE TABLE `leave_admin_section` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `Sname` varchar(20) NOT NULL COMMENT '部门',
  `Marid` int(10) DEFAULT NULL COMMENT '创建者id',
  `Marname` varchar(10) DEFAULT NULL COMMENT '创建人',
  `Martime` int(10) DEFAULT NULL COMMENT '创建时间',
  `px` int(10) NOT NULL DEFAULT '1' COMMENT '使用状态，1正常，0禁止',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of leave_admin_section
-- ----------------------------

-- ----------------------------
-- Table structure for leave_admin_users
-- ----------------------------
DROP TABLE IF EXISTS `leave_admin_users`;
CREATE TABLE `leave_admin_users` (
  `uid` int(10) NOT NULL AUTO_INCREMENT COMMENT '员工ID',
  `uName` varchar(200) NOT NULL COMMENT '员工名',
  `aAccount` varchar(255) NOT NULL COMMENT '登陆账号',
  `aPass` varchar(32) NOT NULL COMMENT '登陆密码',
  `uAttend` varchar(6) NOT NULL COMMENT '验证码',
  `uGroupId` int(10) NOT NULL COMMENT '权限组ID',
  `sectionid` int(10) NOT NULL COMMENT '部门id',
  `uGuildList` int(10) NOT NULL COMMENT '列表，序列化存储',
  `uPhone` varchar(20) NOT NULL COMMENT '联系电话',
  `uMail` varchar(255) NOT NULL COMMENT '联系mail',
  `uCreateTime` int(10) NOT NULL COMMENT '账号创建时间',
  `uLastLoginTime` int(10) NOT NULL COMMENT '上次登陆时间',
  `uLastLoginIp` varchar(20) NOT NULL COMMENT '上次登陆IP',
  `uLoginCount` int(10) NOT NULL COMMENT '登陆次数',
  `uLoginState` tinyint(1) NOT NULL COMMENT '使用状态',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of leave_admin_users
-- ----------------------------

-- ----------------------------
-- Table structure for loginGameUrl
-- ----------------------------
DROP TABLE IF EXISTS `loginGameUrl`;
CREATE TABLE `loginGameUrl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `game_id` int(10) NOT NULL,
  `server_id` int(10) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `sign` varchar(50) NOT NULL,
  `number` int(10) NOT NULL DEFAULT '0' COMMENT '加密数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='免登陆游戏链接账号表';

-- ----------------------------
-- Records of loginGameUrl
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_apply_amend
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_apply_amend`;
CREATE TABLE `mobile_games_apply_amend` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL COMMENT '关联id',
  `uid` int(10) NOT NULL COMMENT '操作人id',
  `ctime` datetime NOT NULL COMMENT '操作时间',
  `state` varchar(50) NOT NULL COMMENT '状态:从a修改为b，如 25-65',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游业绩修改记录表';

-- ----------------------------
-- Records of mobile_games_apply_amend
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_card
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_card`;
CREATE TABLE `mobile_games_card` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(60) DEFAULT '0' COMMENT '订单号',
  `card_money` varchar(15) NOT NULL COMMENT '金额',
  `card_number` varchar(50) NOT NULL COMMENT '卡号',
  `card_pwd` varchar(15) NOT NULL COMMENT '卡密',
  `addtime` int(11) DEFAULT '0' COMMENT '卡号添加时间,0为不计入剩余金额里面',
  `applytime` date DEFAULT NULL COMMENT '申请时间',
  `dotime` datetime DEFAULT NULL COMMENT '审核时间',
  `applyname` varchar(25) DEFAULT NULL COMMENT '申请人',
  `userid` int(10) DEFAULT NULL COMMENT '审核人id',
  `start` tinyint(4) DEFAULT '-1' COMMENT '-1为未使用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游卡号管理表';

-- ----------------------------
-- Records of mobile_games_card
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_card_apply
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_card_apply`;
CREATE TABLE `mobile_games_card_apply` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id,自增',
  `orderid` varchar(60) DEFAULT '0' COMMENT '编号',
  `game_id` int(10) DEFAULT '0' COMMENT '游戏id',
  `server` varchar(20) NOT NULL COMMENT '区服',
  `game_role` varchar(50) DEFAULT NULL COMMENT '游戏角色',
  `account` varchar(25) NOT NULL COMMENT '账号',
  `pwd` varchar(25) NOT NULL COMMENT '密码',
  `port_id` int(10) DEFAULT '0' COMMENT '端口id',
  `value_money_sum` text NOT NULL COMMENT '面额和数量',
  `tote_sum` int(10) NOT NULL COMMENT '汇总',
  `card_number` text COMMENT '不同类型的卡号',
  `order_number` varchar(50) DEFAULT NULL COMMENT '备注',
  `pay_way` varchar(50) DEFAULT NULL COMMENT '收款渠道',
  `pay_way_money` float DEFAULT NULL COMMENT '收款金额',
  `proposer` varchar(20) NOT NULL COMMENT '申请人',
  `proposerid` int(10) DEFAULT '0' COMMENT '申请人id',
  `apply_date` datetime NOT NULL COMMENT '申请时间',
  `affiliation` int(10) DEFAULT '0' COMMENT '该订单归属人',
  `start` int(10) DEFAULT '0' COMMENT '状态，0为待审核，1为通过，2为已发状态',
  `auditing_date` datetime DEFAULT NULL COMMENT '审核时间',
  `reason` varchar(50) DEFAULT NULL COMMENT '拒绝理由',
  `assigid` int(10) DEFAULT '0' COMMENT '指派给谁发放卡号',
  `audit_id` int(10) DEFAULT '0' COMMENT '审核人ID',
  `check` tinyint(4) DEFAULT '0' COMMENT '数据核对标记符，1为已核对',
  `is_new` tinyint(4) DEFAULT '0' COMMENT '数据是否为新增，1为是',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4988 DEFAULT CHARSET=utf8 COMMENT='手游卡号申请表';

-- ----------------------------
-- Records of mobile_games_card_apply
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_card_apply_order
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_card_apply_order`;
CREATE TABLE `mobile_games_card_apply_order` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `cid` int(10) NOT NULL COMMENT '关联id，与mobile_game_card_apply id关联',
  `money` int(10) DEFAULT NULL COMMENT '金额',
  `orderid` text COMMENT '订单号信息',
  `uid` int(10) DEFAULT '0' COMMENT '操作人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游订单信息表';

-- ----------------------------
-- Records of mobile_games_card_apply_order
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_card_count
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_card_count`;
CREATE TABLE `mobile_games_card_count` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `count_money` int(10) NOT NULL COMMENT '导入卡号的总金额',
  `money` int(10) DEFAULT '0' COMMENT '实际录入金额',
  `addtime` int(11) NOT NULL COMMENT '导入时间',
  `uid` int(10) DEFAULT '0' COMMENT '操作人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游游戏导入卡号记录表';

-- ----------------------------
-- Records of mobile_games_card_count
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_list
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_list`;
CREATE TABLE `mobile_games_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游游戏列表';

-- ----------------------------
-- Records of mobile_games_list
-- ----------------------------

-- ----------------------------
-- Table structure for mobile_games_port
-- ----------------------------
DROP TABLE IF EXISTS `mobile_games_port`;
CREATE TABLE `mobile_games_port` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='手游游戏端口表';

-- ----------------------------
-- Records of mobile_games_port
-- ----------------------------

-- ----------------------------
-- Table structure for open_file
-- ----------------------------
DROP TABLE IF EXISTS `open_file`;
CREATE TABLE `open_file` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL COMMENT '公会',
  `commander` varchar(50) NOT NULL COMMENT '军团长',
  `comman` varchar(50) NOT NULL COMMENT '团长',
  `pt_id` int(10) NOT NULL COMMENT '平台',
  `game_id` int(10) NOT NULL COMMENT '游戏',
  `server_id` varchar(12) NOT NULL COMMENT '区服',
  `file` varchar(25) NOT NULL COMMENT '档期',
  `comman_account` varchar(50) NOT NULL COMMENT '团长账号',
  `day_reg` int(10) NOT NULL COMMENT '当天注册',
  `day_income` int(10) NOT NULL COMMENT '当天收入',
  `date_time` date NOT NULL COMMENT '日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=580 DEFAULT CHARSET=utf8 COMMENT='开档录入';

-- ----------------------------
-- Records of open_file
-- ----------------------------

-- ----------------------------
-- Table structure for personnel_apply
-- ----------------------------
DROP TABLE IF EXISTS `personnel_apply`;
CREATE TABLE `personnel_apply` (
  `Id` int(10) NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `user` varchar(20) NOT NULL COMMENT '姓名',
  `Section` int(10) NOT NULL COMMENT '部门id',
  `Start` int(10) NOT NULL COMMENT '请假时间（年，月，日））',
  `startTime` int(10) NOT NULL COMMENT '请假时间（小时）',
  `Last` int(10) NOT NULL COMMENT '请假结束时间（年，月，日）',
  `lastTime` int(10) NOT NULL COMMENT '请假结束时间（小时）',
  `Style` int(10) NOT NULL COMMENT '请假类型',
  `Reason` varchar(100) NOT NULL COMMENT '请假理由',
  `Time` datetime NOT NULL COMMENT '操作时间',
  `Cid` int(10) NOT NULL DEFAULT '-1' COMMENT '部门主管审批，-1为未审批，1为通过，0为不通过',
  `Chname` varchar(10) DEFAULT NULL COMMENT '主管签名',
  `Cdatetime` datetime DEFAULT NULL COMMENT '主管审批时间',
  `Minid` int(10) NOT NULL DEFAULT '-1' COMMENT '人事部审核，-1待审批，1通过，0不通过',
  `Mname` varchar(10) DEFAULT NULL COMMENT '人事签名',
  `Mdatetime` datetime DEFAULT NULL COMMENT '人事 审批时间',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of personnel_apply
-- ----------------------------

-- ----------------------------
-- Table structure for platform_into
-- ----------------------------
DROP TABLE IF EXISTS `platform_into`;
CREATE TABLE `platform_into` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL COMMENT '平台',
  `url` varchar(250) DEFAULT NULL COMMENT '平台连接',
  `user` varchar(50) DEFAULT NULL COMMENT '后台账号',
  `psd` varchar(50) DEFAULT NULL COMMENT '后台密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='平台录入表';

-- ----------------------------
-- Records of platform_into
-- ----------------------------

-- ----------------------------
-- Table structure for play_money
-- ----------------------------
DROP TABLE IF EXISTS `play_money`;
CREATE TABLE `play_money` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pt_id` int(10) NOT NULL COMMENT '平台id',
  `income` int(10) NOT NULL COMMENT '收入',
  `drop` decimal(10,1) NOT NULL DEFAULT '60.0' COMMENT '点数',
  `inner_money` float NOT NULL COMMENT '内充',
  `innerdrop` decimal(10,1) NOT NULL DEFAULT '35.0' COMMENT '内充点数',
  `count_money` float NOT NULL COMMENT '实际金额',
  `pay_money` float NOT NULL COMMENT '打款金额',
  `diff_money` float DEFAULT '0' COMMENT '相差金额',
  `s_time` date NOT NULL COMMENT '开始时间',
  `e_time` date NOT NULL COMMENT '结束时间',
  `pay_date` date DEFAULT NULL COMMENT '打款时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=191 DEFAULT CHARSET=utf8 COMMENT='平台打款录入表';

-- ----------------------------
-- Records of play_money
-- ----------------------------

-- ----------------------------
-- Table structure for pop_pay
-- ----------------------------
DROP TABLE IF EXISTS `pop_pay`;
CREATE TABLE `pop_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `site_id` varchar(20) NOT NULL,
  `pop_ip` int(32) NOT NULL,
  `pop_pay` double NOT NULL,
  `pop_zk` int(4) NOT NULL DEFAULT '0',
  `pop_jl` int(4) NOT NULL DEFAULT '0',
  `state` tinyint(1) NOT NULL DEFAULT '0',
  `s_date` date NOT NULL,
  `e_date` date NOT NULL,
  `pay_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pop_pay
-- ----------------------------

-- ----------------------------
-- Table structure for pt_income
-- ----------------------------
DROP TABLE IF EXISTS `pt_income`;
CREATE TABLE `pt_income` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) DEFAULT '0' COMMENT '公会',
  `pt_id` int(10) NOT NULL COMMENT '平台',
  `money` int(10) NOT NULL COMMENT '金额',
  `date_time` date NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='平台收入录入表';

-- ----------------------------
-- Records of pt_income
-- ----------------------------

-- ----------------------------
-- Table structure for publicity_into
-- ----------------------------
DROP TABLE IF EXISTS `publicity_into`;
CREATE TABLE `publicity_into` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) NOT NULL COMMENT '公会',
  `publicity_money` int(10) NOT NULL COMMENT '外宣',
  `admit_money` int(10) NOT NULL COMMENT '接待',
  `yy_count` int(10) NOT NULL COMMENT 'YY人数',
  `date_time` date NOT NULL COMMENT '日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COMMENT='外宣费录入表';

-- ----------------------------
-- Records of publicity_into
-- ----------------------------

-- ----------------------------
-- Table structure for settle_accounts
-- ----------------------------
DROP TABLE IF EXISTS `settle_accounts`;
CREATE TABLE `settle_accounts` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `sDate` int(10) NOT NULL COMMENT '结算起始日期Ymd',
  `eDate` int(10) NOT NULL COMMENT '结算结束日期Ymd',
  `agent_id` int(10) NOT NULL COMMENT '渠道id',
  `payMoney` int(10) NOT NULL COMMENT '渠道充值金额',
  `loPay` int(10) NOT NULL COMMENT '内充金额',
  `rebatePay` int(10) NOT NULL COMMENT '支付给渠道的金额',
  `logTime` int(10) NOT NULL COMMENT '日志时间',
  `aUid` int(10) NOT NULL COMMENT '操作人id',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='cps结算记录表';

-- ----------------------------
-- Records of settle_accounts
-- ----------------------------

-- ----------------------------
-- Table structure for site_adlist
-- ----------------------------
DROP TABLE IF EXISTS `site_adlist`;
CREATE TABLE `site_adlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL COMMENT '渠道id',
  `site_id` int(11) NOT NULL COMMENT '广告位id',
  `sitename` varchar(60) NOT NULL COMMENT '广告位名称',
  `siteurl` varchar(100) DEFAULT NULL,
  `adtype` tinyint(4) NOT NULL COMMENT '广告投放类型',
  `webtype` tinyint(4) NOT NULL COMMENT '站点类型',
  `adtime` int(11) NOT NULL DEFAULT '0' COMMENT '间隔时间',
  `adturn` int(11) NOT NULL DEFAULT '0' COMMENT '弹窗轮数',
  `adwait` int(11) NOT NULL DEFAULT '0' COMMENT '延时弹窗',
  `width` int(11) DEFAULT NULL COMMENT '尺寸(长)',
  `height` int(11) DEFAULT NULL COMMENT '尺寸(宽)',
  `template` varchar(60) NOT NULL,
  `adid` varchar(10000) DEFAULT NULL COMMENT '创意id',
  `state` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:有效0:无效',
  `edit_time` datetime DEFAULT NULL COMMENT '修改时间',
  `rsync_time` datetime DEFAULT NULL COMMENT '同步时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of site_adlist
-- ----------------------------

-- ----------------------------
-- Table structure for site_logs
-- ----------------------------
DROP TABLE IF EXISTS `site_logs`;
CREATE TABLE `site_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL COMMENT '站点id',
  `adid` varchar(10000) NOT NULL COMMENT '修改创意',
  `edit_time` datetime NOT NULL COMMENT '修改时间',
  `rsync_time` datetime NOT NULL COMMENT '同步时间',
  `logtype` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 正常切换，1 测试切换',
  `author` varchar(11) NOT NULL COMMENT '修改者',
  `state` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否切换',
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of site_logs
-- ----------------------------

-- ----------------------------
-- Table structure for tmp_filepath_save
-- ----------------------------
DROP TABLE IF EXISTS `tmp_filepath_save`;
CREATE TABLE `tmp_filepath_save` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `data` text NOT NULL,
  `uid` int(10) NOT NULL,
  `tTime` int(10) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1371 DEFAULT CHARSET=utf8 COMMENT='文件路径临时保存表';

-- ----------------------------
-- Records of tmp_filepath_save
-- ----------------------------

-- ----------------------------
-- Table structure for unions_news
-- ----------------------------
DROP TABLE IF EXISTS `unions_news`;
CREATE TABLE `unions_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `type` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:联盟公告2:常见问题',
  `addtime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `top` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1:不置顶2:置顶3:全局置顶',
  `hot` tinyint(4) NOT NULL DEFAULT '0',
  `author` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of unions_news
-- ----------------------------

-- ----------------------------
-- Table structure for website_type
-- ----------------------------
DROP TABLE IF EXISTS `website_type`;
CREATE TABLE `website_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of website_type
-- ----------------------------
