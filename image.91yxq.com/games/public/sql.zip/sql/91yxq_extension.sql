/*
Navicat MySQL Data Transfer

Source Server         : 58.215.142.186
Source Server Version : 50533
Source Host           : 58.215.142.186:3306
Source Database       : 91yxq_extension

Target Server Type    : MYSQL
Target Server Version : 50533
File Encoding         : 65001

Date: 2017-12-28 13:42:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for acc_login_total
-- ----------------------------
DROP TABLE IF EXISTS `acc_login_total`;
CREATE TABLE `acc_login_total` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tdate` date NOT NULL,
  `agent_id` int(11) NOT NULL,
  `cid` int(11) DEFAULT '0',
  `placeid` varchar(100) NOT NULL,
  `adid` varchar(10) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  `server_id` int(11) DEFAULT NULL,
  `login_new` int(11) DEFAULT '0',
  `login_old` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tdate` (`tdate`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of acc_login_total
-- ----------------------------

-- ----------------------------
-- Table structure for active_total_h
-- ----------------------------
DROP TABLE IF EXISTS `active_total_h`;
CREATE TABLE `active_total_h` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tdate` date NOT NULL COMMENT '注册日期',
  `thour` int(11) NOT NULL COMMENT '注册小时',
  `agent_id` int(11) NOT NULL,
  `site_id` varchar(50) DEFAULT '0',
  `adid` varchar(10) DEFAULT NULL,
  `active` int(11) DEFAULT '0' COMMENT '活跃数',
  PRIMARY KEY (`id`),
  KEY `tdate` (`tdate`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of active_total_h
-- ----------------------------

-- ----------------------------
-- Table structure for ad_cheat
-- ----------------------------
DROP TABLE IF EXISTS `ad_cheat`;
CREATE TABLE `ad_cheat` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `agent_id` mediumint(6) unsigned NOT NULL COMMENT '渠道id',
  `site_id` mediumint(6) unsigned NOT NULL COMMENT '广告位id',
  `reg_count` mediumint(6) NOT NULL COMMENT '注册人数',
  `ref_url_count` mediumint(6) NOT NULL COMMENT '有注册来路',
  `ref_url_not_count` smallint(5) unsigned NOT NULL COMMENT '没有注册来路',
  `reg_time` int(11) NOT NULL COMMENT '注册时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='广告作弊分析表';

-- ----------------------------
-- Records of ad_cheat
-- ----------------------------

-- ----------------------------
-- Table structure for check_code_login
-- ----------------------------
DROP TABLE IF EXISTS `check_code_login`;
CREATE TABLE `check_code_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(30) NOT NULL COMMENT '用户名',
  `code` varchar(100) NOT NULL COMMENT '验证码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='安卓验证码表';

-- ----------------------------
-- Records of check_code_login
-- ----------------------------

-- ----------------------------
-- Table structure for city
-- ----------------------------
DROP TABLE IF EXISTS `city`;
CREATE TABLE `city` (
  `cityID` int(11) NOT NULL AUTO_INCREMENT,
  `cityName` varchar(50) NOT NULL,
  `proID` int(11) NOT NULL,
  PRIMARY KEY (`cityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of city
-- ----------------------------

-- ----------------------------
-- Table structure for game_company
-- ----------------------------
DROP TABLE IF EXISTS `game_company`;
CREATE TABLE `game_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of game_company
-- ----------------------------
INSERT INTO `game_company` VALUES ('35', '北京世界星辉');

-- ----------------------------
-- Table structure for ip_login_list
-- ----------------------------
DROP TABLE IF EXISTS `ip_login_list`;
CREATE TABLE `ip_login_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `num` int(11) NOT NULL,
  `num_local` int(11) DEFAULT NULL,
  `num_other` int(11) DEFAULT NULL,
  `state` tinyint(4) NOT NULL,
  `tdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ip_login_list
-- ----------------------------

-- ----------------------------
-- Table structure for kf_yb_apply
-- ----------------------------
DROP TABLE IF EXISTS `kf_yb_apply`;
CREATE TABLE `kf_yb_apply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_id` tinyint(4) NOT NULL,
  `username` varchar(50) NOT NULL,
  `orderid` varchar(50) NOT NULL,
  `money` float NOT NULL,
  `gold` float NOT NULL,
  `pay_date` varchar(20) DEFAULT NULL,
  `pay_bank` varchar(50) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `pay_type` tinyint(4) NOT NULL,
  `pay_memo` text NOT NULL,
  `addtime` datetime NOT NULL,
  `edittime` datetime DEFAULT NULL,
  `addautor` varchar(10) NOT NULL,
  `editautor` varchar(10) DEFAULT NULL,
  `state` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kf_yb_apply
-- ----------------------------

-- ----------------------------
-- Table structure for login_total
-- ----------------------------
DROP TABLE IF EXISTS `login_total`;
CREATE TABLE `login_total` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tdate` date NOT NULL,
  `agent_id` int(11) NOT NULL,
  `site_id` varchar(100) DEFAULT '0',
  `adid` varchar(10) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  `server_id` int(11) DEFAULT NULL,
  `turn` int(11) NOT NULL,
  `cplaceid` varchar(50) DEFAULT NULL,
  `login_new` int(11) DEFAULT '0',
  `login_new_ip` int(10) NOT NULL DEFAULT '0',
  `login_old` int(11) DEFAULT '0',
  `login_old_ip` int(10) NOT NULL DEFAULT '0',
  `login_b1` int(11) DEFAULT '0',
  `login_b2` int(11) DEFAULT '0',
  `login_b3` int(11) DEFAULT '0',
  `login_b4` int(11) DEFAULT '0',
  `login_b5` int(11) DEFAULT '0',
  `login_b6` int(11) DEFAULT '0',
  `login_b7` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tdate` (`tdate`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login_total
-- ----------------------------

-- ----------------------------
-- Table structure for login_zone
-- ----------------------------
DROP TABLE IF EXISTS `login_zone`;
CREATE TABLE `login_zone` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) unsigned NOT NULL,
  `site_id` int(10) unsigned NOT NULL,
  `login_b1` int(11) NOT NULL,
  `cityID` int(10) unsigned NOT NULL,
  `proID` int(11) DEFAULT NULL,
  `platform_id` tinyint(3) unsigned NOT NULL,
  `tdate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cityID` (`cityID`,`proID`),
  KEY `agent_id` (`agent_id`,`site_id`),
  KEY `tdate` (`tdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login_zone
-- ----------------------------

-- ----------------------------
-- Table structure for pay_list_zone
-- ----------------------------
DROP TABLE IF EXISTS `pay_list_zone`;
CREATE TABLE `pay_list_zone` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderid` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `money` float NOT NULL,
  `pay_date` datetime NOT NULL,
  `agent_id` int(11) NOT NULL,
  `placeid` varchar(100) DEFAULT '0',
  `adid` varchar(100) DEFAULT NULL,
  `game_id` int(11) NOT NULL,
  `server_id` int(11) NOT NULL,
  `reg_date` datetime NOT NULL,
  `sync_date` datetime NOT NULL,
  `proID` int(11) NOT NULL DEFAULT '0',
  `cityID` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`orderid`),
  KEY `agent_id` (`agent_id`),
  KEY `pay_date` (`pay_date`),
  KEY `game_id` (`game_id`),
  KEY `server_id` (`server_id`),
  KEY `user_name` (`user_name`),
  KEY `sync_date` (`sync_date`),
  KEY `proID` (`proID`,`cityID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pay_list_zone
-- ----------------------------

-- ----------------------------
-- Table structure for province
-- ----------------------------
DROP TABLE IF EXISTS `province`;
CREATE TABLE `province` (
  `proID` int(11) NOT NULL,
  `proName` varchar(50) NOT NULL,
  PRIMARY KEY (`proID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of province
-- ----------------------------

-- ----------------------------
-- Table structure for reg_total
-- ----------------------------
DROP TABLE IF EXISTS `reg_total`;
CREATE TABLE `reg_total` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tdate` date NOT NULL,
  `thour` tinyint(4) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `site_id` varchar(100) DEFAULT '0',
  `adid` varchar(10) DEFAULT NULL,
  `turn` int(11) NOT NULL COMMENT '注册轮数',
  `reg_count` int(11) NOT NULL,
  `reg_ip_count` int(10) NOT NULL DEFAULT '0' COMMENT '注册ip数',
  `login_count` int(11) NOT NULL,
  `game_id` int(11) NOT NULL,
  `server_id` int(11) DEFAULT '0' COMMENT '服务器id',
  `cplaceid` varchar(50) DEFAULT NULL COMMENT '子id',
  PRIMARY KEY (`id`),
  KEY `tdate` (`tdate`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reg_total
-- ----------------------------

-- ----------------------------
-- Table structure for reg_zone
-- ----------------------------
DROP TABLE IF EXISTS `reg_zone`;
CREATE TABLE `reg_zone` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` int(10) unsigned NOT NULL,
  `site_id` int(10) unsigned NOT NULL,
  `reg_count` int(11) NOT NULL,
  `cityID` int(10) unsigned NOT NULL,
  `proID` int(11) DEFAULT NULL,
  `platform_id` tinyint(3) unsigned NOT NULL,
  `reg_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cityID` (`cityID`,`proID`),
  KEY `agent_id` (`agent_id`,`site_id`),
  KEY `reg_date` (`reg_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reg_zone
-- ----------------------------

-- ----------------------------
-- Table structure for sync_game_reg_login
-- ----------------------------
DROP TABLE IF EXISTS `sync_game_reg_login`;
CREATE TABLE `sync_game_reg_login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `time` int(10) NOT NULL COMMENT '统计时间',
  `reg_user` int(10) NOT NULL COMMENT '当日注册用户',
  `reg_ip` int(10) NOT NULL COMMENT '当日注册IP',
  `login_user` int(10) NOT NULL COMMENT '当日登陆用户',
  `login_ip` int(10) NOT NULL COMMENT '当日登陆IP',
  `date` int(10) NOT NULL COMMENT '统计日期',
  `game_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='每日游戏用户统计表';

-- ----------------------------
-- Records of sync_game_reg_login
-- ----------------------------

-- ----------------------------
-- Table structure for sync_user_statistics
-- ----------------------------
DROP TABLE IF EXISTS `sync_user_statistics`;
CREATE TABLE `sync_user_statistics` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `time` int(10) NOT NULL COMMENT '统计时间',
  `reg_user` int(10) NOT NULL COMMENT '当日注册用户',
  `reg_ip` int(10) NOT NULL COMMENT '当日注册IP',
  `login_user` int(10) NOT NULL COMMENT '当日登陆用户',
  `login_ip` int(10) NOT NULL COMMENT '当日登陆IP',
  `date` int(10) NOT NULL COMMENT '统计日期',
  `mx_user` smallint(5) unsigned NOT NULL COMMENT '官网用户',
  `mx_ip` smallint(5) unsigned NOT NULL COMMENT '官网IP',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='每日用户统计表';

-- ----------------------------
-- Records of sync_user_statistics
-- ----------------------------

-- ----------------------------
-- Table structure for user_analyse
-- ----------------------------
DROP TABLE IF EXISTS `user_analyse`;
CREATE TABLE `user_analyse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `oldreg_count` int(11) NOT NULL,
  `newreg_count` int(11) NOT NULL,
  `old_paypeople` int(11) NOT NULL,
  `new_paypeople` int(11) NOT NULL,
  `old_paymoney` int(11) NOT NULL,
  `new_paymoney` int(11) NOT NULL,
  `agent_id` int(11) DEFAULT '0',
  `cid` varchar(50) DEFAULT NULL,
  `adid` varchar(50) DEFAULT NULL,
  `game_id` int(10) NOT NULL,
  `server_id` int(11) NOT NULL,
  `tdate` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`),
  KEY `server_id` (`server_id`),
  KEY `tdate` (`tdate`),
  KEY `agent_id` (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_analyse
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_action
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_action`;
CREATE TABLE `xieenet_action` (
  `actionid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL COMMENT '栏目ID',
  `actionname` varchar(200) NOT NULL,
  `actionphpname` varchar(50) NOT NULL,
  `aorder` tinyint(4) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`actionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_action
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_action_log
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_action_log`;
CREATE TABLE `xieenet_action_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `log_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `log_time` (`log_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_action_log
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_column
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_column`;
CREATE TABLE `xieenet_column` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `proid` int(11) NOT NULL COMMENT '项目id',
  `cname` varchar(100) NOT NULL,
  `corder` int(11) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_column
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_dept
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_dept`;
CREATE TABLE `xieenet_dept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `dept` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_dept
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_doc_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_doc_list`;
CREATE TABLE `xieenet_doc_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `type_small_name` varchar(50) NOT NULL,
  `game_name` varchar(50) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `content` mediumtext,
  `autor` varchar(50) NOT NULL,
  `add_time` datetime NOT NULL,
  `editor` varchar(50) NOT NULL,
  `edit_time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_doc_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_docgame_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_docgame_list`;
CREATE TABLE `xieenet_docgame_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `game_name` varchar(50) NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_docgame_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_doctype_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_doctype_list`;
CREATE TABLE `xieenet_doctype_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `type_name` varchar(50) NOT NULL,
  `type_small_name` text NOT NULL,
  `rank` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_doctype_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_domain_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_domain_list`;
CREATE TABLE `xieenet_domain_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `platform_id` tinyint(4) NOT NULL,
  `game_name` varchar(10) NOT NULL,
  `domain` varchar(20) NOT NULL,
  `tele_ip` varchar(100) NOT NULL,
  `cnc_ip` varchar(20) NOT NULL,
  `optype` varchar(10) NOT NULL,
  `mxtype` varchar(10) NOT NULL,
  `author` varchar(20) NOT NULL,
  `addtime` datetime NOT NULL,
  `application` varchar(200) DEFAULT NULL,
  `state` tinyint(4) NOT NULL COMMENT '(1:未处理2:成功3:忽略4:失败)',
  `edit_time` datetime DEFAULT NULL,
  `edit_author` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_domain_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_gamelist
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_gamelist`;
CREATE TABLE `xieenet_gamelist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `game_name` varchar(200) NOT NULL,
  `oid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `game_name` (`game_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_gamelist
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_groupmanager
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_groupmanager`;
CREATE TABLE `xieenet_groupmanager` (
  `groupid` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(100) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_groupmanager
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_idc_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_idc_list`;
CREATE TABLE `xieenet_idc_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `contact_info` text,
  `remark` varchar(200) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_idc_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_jigui_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_jigui_list`;
CREATE TABLE `xieenet_jigui_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idc_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `network` varchar(50) NOT NULL,
  `create_date` datetime NOT NULL,
  `max_machine` int(11) NOT NULL,
  `switch_num` int(11) DEFAULT NULL,
  `switch_model` varchar(100) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_jigui_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_loginsession
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_loginsession`;
CREATE TABLE `xieenet_loginsession` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(60) NOT NULL,
  `errorcount` int(11) NOT NULL,
  `logintime` int(11) NOT NULL,
  `loginip` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_loginsession
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_openplan_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_openplan_list`;
CREATE TABLE `xieenet_openplan_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vdate` date NOT NULL,
  `vweek` varchar(20) NOT NULL,
  `game_id` int(11) NOT NULL,
  `game_name` varchar(30) DEFAULT NULL,
  `vtime` varchar(30) NOT NULL,
  `server_id` int(11) NOT NULL,
  `server_name` varchar(30) NOT NULL,
  `jifang` varchar(255) NOT NULL DEFAULT '',
  `platform_id` int(11) NOT NULL,
  `remark` varchar(255) NOT NULL DEFAULT '',
  `edit_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tips` int(11) NOT NULL DEFAULT '0' COMMENT '更新提示',
  `state` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 草稿 1 发布',
  PRIMARY KEY (`id`),
  KEY `game_id` (`game_id`,`server_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_openplan_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_operate_log
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_operate_log`;
CREATE TABLE `xieenet_operate_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `op_date` datetime NOT NULL,
  `op_content` text NOT NULL,
  `pay_type` varchar(200) DEFAULT NULL,
  `is_login` int(11) DEFAULT '1',
  `ip` varchar(20) NOT NULL,
  `url` varchar(200) DEFAULT NULL,
  `dept` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pay_type` (`pay_type`)
) ENGINE=InnoDB AUTO_INCREMENT=79074 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_operate_log
-- ----------------------------
INSERT INTO `xieenet_operate_log` VALUES ('78989', 'admin', '2017-02-15 11:34:37', '登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78990', 'admin', '2017-02-15 11:34:42', '登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78991', 'admin', '2017-02-15 13:23:34', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78992', 'admin', '2017-02-15 14:56:44', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78993', 'admin', '2017-02-15 14:58:18', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78994', 'admin', '2017-02-15 14:58:50', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78995', 'admin', '2017-02-15 14:59:05', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78996', 'admin', '2017-02-15 14:59:26', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78997', 'admin', '2017-02-15 15:00:17', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78998', 'admin', '2017-02-15 15:02:01', 'admin登录玩家yinkun123|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('78999', 'admin', '2017-02-15 15:03:29', 'admin登录玩家yinkun123|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79000', 'admin', '2017-02-15 15:25:10', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79001', 'admin', '2017-02-15 15:31:22', 'admin登录玩家yinkun|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79002', 'admin', '2017-02-15 15:50:10', 'admin登录玩家yinkun|test', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79003', 'admin', '2017-02-15 19:07:16', 'admin登录玩家yinkun|1', '91yxq', '1', '113.65.160.232', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79004', 'admin', '2017-02-16 09:36:18', 'admin登录玩家yinkun|123', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79005', 'admin', '2017-02-16 09:40:07', 'admin登录玩家yinkun|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79006', 'admin', '2017-02-16 10:03:05', 'admin登录玩家yinkun|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79007', 'admin', '2017-02-16 10:09:39', 'admin登录玩家jason1209|看一下', '91yxq', '1', '114.222.113.29', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79008', 'admin', '2017-02-16 11:03:11', 'admin登录玩家yinkun|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79009', 'admin', '2017-02-16 14:10:38', 'admin登录玩家jason1209|aaa ', '91yxq', '1', '114.222.113.29', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79010', 'admin', '2017-02-17 10:26:02', 'admin登录玩家aaaaaaa|aaaaaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79011', 'admin', '2017-02-17 10:26:24', 'admin登录玩家aaaaaaa|aaaaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79012', 'admin', '2017-02-17 10:42:05', 'admin登录玩家yinkun|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79013', 'admin', '2017-02-17 10:43:12', 'admin登录玩家yinkun1231|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79014', 'admin', '2017-02-17 16:22:00', 'admin登录玩家aaaaaa|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79015', 'admin', '2017-02-17 16:31:18', 'admin登录玩家aaaaaa|1', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79016', 'admin', '2017-02-17 17:31:13', 'admin登录玩家aaaaaa|aaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79017', 'admin', '2017-02-17 17:32:52', 'admin登录玩家aaaaaa|aaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79018', 'admin', '2017-02-17 17:33:23', 'admin登录玩家aaaaaa|aaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79019', 'admin', '2017-02-17 17:34:37', 'admin登录玩家aaaaaa|aaaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79020', 'admin', '2017-02-17 17:35:15', 'admin登录玩家aaaaaa|aaaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79021', 'admin', '2017-02-23 11:30:57', 'admin登录玩家aaaaaa|aaaa', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79022', 'admin', '2017-08-07 16:05:34', 'admin登录玩家allen|ceshi', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79023', '91yxq_36710', '2017-08-07 16:20:52', '登录玩家91yxq_36710%E6%AD%A6%E7%A5%9E%E8%B5%B5%E5%AD%90%E9%BE%99%E5%8F%8C%E7%BA%BF48%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79024', '91yxq_36710', '2017-08-07 16:22:35', '登录玩家91yxq_36710%E6%AD%A6%E7%A5%9E%E8%B5%B5%E5%AD%90%E9%BE%99%E5%8F%8C%E7%BA%BF48%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79025', '91yxq_36710', '2017-08-07 16:29:33', '登录玩家91yxq_36710%E7%83%AD%E8%A1%80%E8%99%8E%E5%8D%AB%E5%8F%8C%E7%BA%BF29%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79026', '91yxq_36710', '2017-08-07 16:29:51', '登录玩家91yxq_36710%E7%83%AD%E8%A1%80%E8%99%8E%E5%8D%AB%E5%8F%8C%E7%BA%BF29%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79027', '91yxq_36710', '2017-08-07 16:47:05', '登录玩家91yxq_36710%E6%96%97%E7%A0%B4%E6%B2%99%E5%9F%8E%E5%8F%8C%E7%BA%BF29%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79028', '91yxq_36710', '2017-08-07 16:47:35', '登录玩家91yxq_36710%E6%96%97%E7%A0%B4%E6%B2%99%E5%9F%8E%E5%8F%8C%E7%BA%BF29%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79029', '91yxq_36710', '2017-08-07 17:06:42', '登录玩家91yxq_36710%E6%88%98%E5%9B%BD%E4%B9%8B%E6%80%92%E5%8F%8C%E7%BA%BF255%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79030', '91yxq_36710', '2017-08-07 17:07:13', '登录玩家91yxq_36710%E6%88%98%E5%9B%BD%E4%B9%8B%E6%80%92%E5%8F%8C%E7%BA%BF255%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79031', '91yxq_36710', '2017-08-07 17:22:54', '登录玩家91yxq_36710%E6%AD%A6%E7%A5%9E%E8%B5%B5%E5%AD%90%E9%BE%99%E5%8F%8C%E7%BA%BF48%E6%9C%8D|', '777wan', '1', '58.240.26.114', 'http://api.91yxq.com/api/enter_game_by_api.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79032', 'admin', '2017-08-24 12:10:39', 'admin登录玩家rwerwe|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79033', 'admin', '2017-08-24 12:11:59', 'admin登录玩家rwerwe|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79034', 'admin', '2017-08-24 12:19:03', 'admin登录玩家rwerwe|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79035', 'admin', '2017-08-24 12:19:44', 'admin登录玩家rwerwe|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79036', 'admin', '2017-09-06 15:52:07', 'admin登录玩家hggh78454|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79037', 'admin', '2017-09-06 16:51:11', 'admin登录玩家xinxinxin111|测', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79038', 'admin', '2017-09-13 14:10:55', 'admin登录玩家fgdgfg555|cei', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79039', 'admin', '2017-09-13 16:00:57', 'admin登录玩家fgdgfg555|cei', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79040', 'admin', '2017-09-18 16:02:11', 'admin登录玩家18342149096|测试', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79041', 'admin', '2017-09-27 09:56:35', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79042', 'admin', '2017-09-27 10:01:39', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79043', 'admin', '2017-09-27 10:02:12', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79044', 'admin', '2017-09-27 10:02:43', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79045', 'admin', '2017-09-27 10:06:42', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79046', 'admin', '2017-09-27 10:07:04', 'admin登录玩家xiluo76|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79047', 'admin', '2017-09-29 09:52:03', 'admin登录玩家gjasjdda1|xe', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79048', 'admin', '2017-09-30 12:04:12', 'admin登录玩家dlcgdf1|cc', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79049', 'admin', '2017-09-30 12:04:26', 'admin登录玩家dlcgdf1|cc', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79050', 'admin', '2017-10-09 10:30:53', 'admin登录玩家qq148578|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79051', 'admin', '2017-10-10 10:24:25', 'admin登录玩家bgy88|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79052', 'admin', '2017-10-10 16:36:28', 'admin登录玩家神之洛熙|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79053', 'admin', '2017-10-12 10:55:28', 'admin登录玩家dyyh731|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79054', 'admin', '2017-10-18 11:18:54', 'admin登录玩家q1507523|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79055', 'admin', '2017-10-18 12:05:27', 'admin登录玩家cqrymiao16|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79056', 'admin', '2017-10-18 12:17:25', 'admin登录玩家qwe252744005|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79057', 'admin', '2017-10-18 12:17:48', 'admin登录玩家qwe252744005|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79058', 'admin', '2017-10-18 12:18:51', 'admin登录玩家885106757|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79059', 'admin', '2017-10-18 12:24:20', 'admin登录玩家fei9070389|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79060', 'admin', '2017-10-18 12:24:44', 'admin登录玩家fei9070389|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79061', 'admin', '2017-10-20 14:11:29', 'admin登录玩家b1020999|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79062', 'admin', '2017-10-24 15:29:23', 'admin登录玩家quan900033|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79063', 'admin', '2017-10-24 15:37:28', 'admin登录玩家skl2kk|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79064', 'admin', '2017-10-24 15:37:40', 'admin登录玩家sdkl2k|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79065', 'admin', '2017-10-24 15:37:51', 'admin登录玩家bvnk2j3|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79066', 'admin', '2017-10-24 16:56:00', 'admin登录玩家tititi0023|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79067', 'admin', '2017-11-07 14:26:02', 'admin登录玩家zztg71797|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79068', 'admin', '2017-11-13 09:56:29', 'admin登录玩家li5346555|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79069', 'admin', '2017-11-13 15:05:32', 'admin登录玩家lovesusan0|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79070', 'admin', '2017-11-17 22:30:15', 'admin登录玩家hao860511|ce', '91yxq', '1', '180.102.146.204', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79071', 'admin', '2017-11-17 22:33:00', 'admin登录玩家hao860511|ce', '91yxq', '1', '180.102.146.204', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79072', 'admin', '2017-11-17 22:35:58', 'admin登录玩家hao860511|ce', '91yxq', '1', '180.102.146.204', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);
INSERT INTO `xieenet_operate_log` VALUES ('79073', 'admin', '2017-12-01 14:47:15', 'admin登录玩家f130138873|ce', '91yxq', '1', '58.240.26.114', 'http://admin.91yxq.com/colligate/loginUserToGame.php', null);

-- ----------------------------
-- Table structure for xieenet_person_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_person_list`;
CREATE TABLE `xieenet_person_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plat` varchar(200) NOT NULL,
  `gamename` text NOT NULL,
  `ogame` varchar(200) NOT NULL,
  `rescontent` varchar(200) NOT NULL,
  `qq` varchar(200) NOT NULL,
  `tel` varchar(200) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `add_user` varchar(50) NOT NULL,
  `add_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rescontent` (`rescontent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_person_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_plat
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_plat`;
CREATE TABLE `xieenet_plat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plat_name` varchar(200) NOT NULL,
  `oid` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plat_name` (`plat_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_plat
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_prj_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_prj_list`;
CREATE TABLE `xieenet_prj_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_prj_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_project
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_project`;
CREATE TABLE `xieenet_project` (
  `pId` int(11) NOT NULL AUTO_INCREMENT,
  `pName` varchar(60) NOT NULL,
  `iorder` int(11) DEFAULT NULL COMMENT '排序',
  `cretat_time` datetime NOT NULL,
  PRIMARY KEY (`pId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_project
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_server_costday
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_server_costday`;
CREATE TABLE `xieenet_server_costday` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plat` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  `idc_id` int(11) NOT NULL,
  `jigui_id` int(11) NOT NULL,
  `prj_id` int(11) DEFAULT NULL,
  `srv_id` int(11) NOT NULL,
  `application` varchar(50) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime DEFAULT NULL,
  `cost_day` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_server_costday
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_server_list
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_server_list`;
CREATE TABLE `xieenet_server_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idc_id` int(11) NOT NULL,
  `jigui_id` int(11) NOT NULL,
  `prj_id` int(11) DEFAULT NULL,
  `tele_ip` varchar(100) NOT NULL,
  `cnc_ip` varchar(100) NOT NULL,
  `network` varchar(100) DEFAULT NULL COMMENT '电信,网通,双线',
  `remark` text,
  `stat` int(11) DEFAULT '0' COMMENT '0=闲置，1=使用, 2=故障',
  `create_date` varchar(50) DEFAULT NULL,
  `sn` varchar(50) DEFAULT NULL,
  `wdsn` varchar(50) DEFAULT NULL,
  `application` varchar(200) DEFAULT NULL,
  `server_model` varchar(200) DEFAULT NULL,
  `buy_date` datetime DEFAULT NULL,
  `alert_rule` tinyint(4) NOT NULL DEFAULT '0',
  `is_handover` tinyint(3) unsigned DEFAULT NULL COMMENT '1:已交付2:未交付',
  `local_graph_id` int(11) NOT NULL DEFAULT '0',
  `plat` int(11) NOT NULL,
  `gid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_server_list
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_server_log
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_server_log`;
CREATE TABLE `xieenet_server_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jqid` int(11) NOT NULL COMMENT '机器ID',
  `tele_ip` varchar(100) NOT NULL,
  `cnc_ip` varchar(100) NOT NULL,
  `prj_id` int(11) DEFAULT NULL,
  `plat` int(10) unsigned NOT NULL,
  `gid` int(10) unsigned NOT NULL,
  `application` varchar(50) DEFAULT NULL,
  `op_date` datetime NOT NULL,
  `op_autor` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_server_log
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_user
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_user`;
CREATE TABLE `xieenet_user` (
  `uId` int(11) NOT NULL AUTO_INCREMENT,
  `pId` varchar(200) DEFAULT NULL COMMENT '所拥有项目权限',
  `cid` varchar(500) DEFAULT NULL COMMENT '拥有栏目权限',
  `uGid` int(11) DEFAULT NULL,
  `uName` varchar(50) NOT NULL,
  `uPass` varchar(64) NOT NULL,
  `truename` varchar(50) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `birthday` datetime DEFAULT NULL,
  `dept` int(11) DEFAULT NULL COMMENT '所属部门',
  `position` int(11) DEFAULT NULL COMMENT '职务',
  `position_desc` text COMMENT '职务说明',
  `office_phone` varchar(50) DEFAULT NULL COMMENT '办公室电话',
  `mobile` varchar(20) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `masterid` int(11) DEFAULT NULL,
  `mastername` int(11) DEFAULT NULL,
  `createdate` datetime DEFAULT NULL COMMENT '创建军时间',
  `LastLoginDate` datetime DEFAULT NULL,
  `LastLoginIp` varchar(30) DEFAULT NULL,
  `actionid` text COMMENT '用户所拥有的动作',
  `sp_gamelist` varchar(256) DEFAULT NULL,
  `logincount` int(11) DEFAULT '0',
  `upwdcount` int(11) DEFAULT '1',
  `upwdtime` datetime DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '1代表账号有效0代表无效',
  PRIMARY KEY (`uId`),
  UNIQUE KEY `uName` (`uName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_user
-- ----------------------------

-- ----------------------------
-- Table structure for xieenet_wdsn_lib
-- ----------------------------
DROP TABLE IF EXISTS `xieenet_wdsn_lib`;
CREATE TABLE `xieenet_wdsn_lib` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wdsn` varchar(50) NOT NULL,
  `create_date` datetime NOT NULL,
  `state` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xieenet_wdsn_lib
-- ----------------------------
